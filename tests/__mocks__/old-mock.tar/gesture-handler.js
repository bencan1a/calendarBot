/**
 * @fileoverview Mock implementation for GestureHandler
 * Provides configurable mock responses for gesture and touch testing
 */

class MockGestureHandler {
  constructor(settingsPanel = null) {
    this.settingsPanel = settingsPanel;
    
    // Mock state
    this.isListening = false;
    this.gestureActive = false;
    this.isDragging = false;
    this.gestureZoneHeight = 50;
    this.dragThreshold = 20;
    this.startY = 0;
    this.currentY = 0;
    this.panelTransitioning = false;
    
    // Mock configuration
    this.shouldFailGesture = false;
    this.gestureDelay = 0;
    this.mockTouchSupport = true;
    
    // Spy on methods
    this.initialize = jest.fn(this._initialize.bind(this));
    this.enable = jest.fn(this._enable.bind(this));
    this.disable = jest.fn(this._disable.bind(this));
    this.destroy = jest.fn(this._destroy.bind(this));
    this.updateGestureZoneHeight = jest.fn(this._updateGestureZoneHeight.bind(this));
    this.createGestureZone = jest.fn(this._createGestureZone.bind(this));
    this.setupEventListeners = jest.fn(this._setupEventListeners.bind(this));
    this.handleTouchStart = jest.fn(this._handleTouchStart.bind(this));
    this.handleTouchMove = jest.fn(this._handleTouchMove.bind(this));
    this.handleTouchEnd = jest.fn(this._handleTouchEnd.bind(this));
    this.handleMouseDown = jest.fn(this._handleMouseDown.bind(this));
    this.handleMouseMove = jest.fn(this._handleMouseMove.bind(this));
    this.handleMouseUp = jest.fn(this._handleMouseUp.bind(this));
    this.showDragIndicator = jest.fn(this._showDragIndicator.bind(this));
    this.hideDragIndicator = jest.fn(this._hideDragIndicator.bind(this));
  }

  // Mock configuration methods
  setShouldFailGesture(shouldFail) {
    this.shouldFailGesture = shouldFail;
  }

  setGestureDelay(delay) {
    this.gestureDelay = delay;
  }

  setTouchSupport(supported) {
    this.mockTouchSupport = supported;
  }

  setMockState(state) {
    Object.assign(this, state);
  }

  // Mock implementation methods
  _initialize() {
    this._createGestureZone();
    this._setupEventListeners();
    
    if (this.shouldFailGesture) {
      throw new Error('Gesture handler initialization failed');
    }
    
    return this;
  }

  _enable() {
    if (this.shouldFailGesture) {
      throw new Error('Failed to enable gesture recognition');
    }
    
    this.isListening = true;
    
    const gestureZone = document.getElementById('settings-gesture-zone');
    if (gestureZone) {
      gestureZone.style.pointerEvents = 'auto';
    }
  }

  _disable() {
    this.isListening = false;
    this.gestureActive = false;
    this.isDragging = false;
    
    const gestureZone = document.getElementById('settings-gesture-zone');
    if (gestureZone) {
      gestureZone.style.pointerEvents = 'none';
    }
    
    this._hideDragIndicator();
  }

  _destroy() {
    this._disable();
    
    const gestureZone = document.getElementById('settings-gesture-zone');
    if (gestureZone) {
      gestureZone.remove();
    }
    
    const dragIndicator = document.getElementById('settings-drag-indicator');
    if (dragIndicator) {
      dragIndicator.remove();
    }
  }

  _updateGestureZoneHeight(height) {
    this.gestureZoneHeight = height;
    
    const gestureZone = document.getElementById('settings-gesture-zone');
    if (gestureZone) {
      gestureZone.style.height = `${height}px`;
    }
    
    const dragIndicator = document.getElementById('settings-drag-indicator');
    if (dragIndicator) {
      dragIndicator.style.top = `${height}px`;
    }
  }

  _createGestureZone() {
    // Remove existing zone
    const existingZone = document.getElementById('settings-gesture-zone');
    if (existingZone) {
      existingZone.remove();
    }

    // Create gesture zone
    const gestureZone = document.createElement('div');
    gestureZone.id = 'settings-gesture-zone';
    gestureZone.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: ${this.gestureZoneHeight}px;
      background: transparent;
      z-index: 9999;
      pointer-events: ${this.isListening ? 'auto' : 'none'};
    `;
    document.body.appendChild(gestureZone);

    // Create drag indicator
    const dragIndicator = document.createElement('div');
    dragIndicator.id = 'settings-drag-indicator';
    dragIndicator.style.cssText = `
      position: fixed;
      top: ${this.gestureZoneHeight}px;
      left: 50%;
      transform: translateX(-50%);
      width: 60px;
      height: 4px;
      background: #007bff;
      border-radius: 2px;
      opacity: 0;
      transition: opacity 0.2s ease;
      z-index: 10000;
    `;
    document.body.appendChild(dragIndicator);
  }

  _setupEventListeners() {
    const gestureZone = document.getElementById('settings-gesture-zone');
    if (!gestureZone) {
      console.log('GestureHandler: Gesture zone not found during event setup');
      return;
    }

    // Touch events
    if (this.mockTouchSupport) {
      gestureZone.addEventListener('touchstart', this.handleTouchStart);
      document.addEventListener('touchmove', this.handleTouchMove);
      document.addEventListener('touchend', this.handleTouchEnd);
    }

    // Mouse events (fallback)
    gestureZone.addEventListener('mousedown', this.handleMouseDown);
    document.addEventListener('mousemove', this.handleMouseMove);
    document.addEventListener('mouseup', this.handleMouseUp);

    // Panel dismissal events
    document.addEventListener('click', this._handleDocumentClick.bind(this));
    document.addEventListener('keydown', this._handleKeyDown.bind(this));
  }

  _handleTouchStart(event) {
    if (!this.isListening || this.panelTransitioning || (this.settingsPanel && this.settingsPanel.isOpen)) {
      return;
    }

    if (this.shouldFailGesture) {
      return;
    }

    const touch = event.changedTouches && event.changedTouches[0];
    if (!touch) return;

    if (touch.clientY <= this.gestureZoneHeight) {
      this.gestureActive = true;
      this.startY = touch.clientY;
      this.currentY = touch.clientY;
      this._showDragIndicator();
    }
  }

  _handleTouchMove(event) {
    if (!this.gestureActive) return;

    const touch = event.changedTouches && event.changedTouches[0];
    if (!touch) return;

    this.currentY = touch.clientY;
    const dragDistance = this.currentY - this.startY;

    if (dragDistance > 0 && dragDistance >= this.dragThreshold && !this.isDragging) {
      this.isDragging = true;
      if (this.settingsPanel && this.settingsPanel.startReveal) {
        this.settingsPanel.startReveal();
      }
    }

    if (this.isDragging && this.settingsPanel && this.settingsPanel.updateReveal) {
      const maxDrag = 200; // Mock max drag distance
      const percentage = Math.min(dragDistance / maxDrag, 1);
      this.settingsPanel.updateReveal(percentage);
    }
  }

  _handleTouchEnd(event) {
    if (!this.gestureActive) return;

    const touch = event.changedTouches && event.changedTouches[0];
    if (!touch) return;

    const dragDistance = touch.clientY - this.startY;
    const completionThreshold = this.dragThreshold * 2;

    if (this.isDragging) {
      if (dragDistance >= completionThreshold && this.settingsPanel && this.settingsPanel.open) {
        this.settingsPanel.open();
      } else if (this.settingsPanel && this.settingsPanel.cancelReveal) {
        this.settingsPanel.cancelReveal();
      }
    }

    this._resetGestureState();
  }

  _handleMouseDown(event) {
    if (!this.isListening || this.panelTransitioning || (this.settingsPanel && this.settingsPanel.isOpen)) {
      return;
    }

    if (event.clientY <= this.gestureZoneHeight) {
      this.gestureActive = true;
      this.startY = event.clientY;
      this.currentY = event.clientY;
      this._showDragIndicator();
    }
  }

  _handleMouseMove(event) {
    if (!this.gestureActive) return;

    this.currentY = event.clientY;
    const dragDistance = this.currentY - this.startY;

    if (dragDistance > 0 && dragDistance >= this.dragThreshold && !this.isDragging) {
      this.isDragging = true;
      if (this.settingsPanel && this.settingsPanel.startReveal) {
        this.settingsPanel.startReveal();
      }
    }

    if (this.isDragging && this.settingsPanel && this.settingsPanel.updateReveal) {
      const maxDrag = 200;
      const percentage = Math.min(dragDistance / maxDrag, 1);
      this.settingsPanel.updateReveal(percentage);
    }
  }

  _handleMouseUp(event) {
    if (!this.gestureActive) return;

    const dragDistance = event.clientY - this.startY;
    const completionThreshold = this.dragThreshold * 2;

    if (this.isDragging) {
      if (dragDistance >= completionThreshold && this.settingsPanel && this.settingsPanel.open) {
        this.settingsPanel.open();
      } else if (this.settingsPanel && this.settingsPanel.cancelReveal) {
        this.settingsPanel.cancelReveal();
      }
    }

    this._resetGestureState();
  }

  _handleDocumentClick(event) {
    if (!this.settingsPanel || !this.settingsPanel.isOpen) return;

    const settingsPanel = document.getElementById('settings-panel');
    const gestureZone = document.getElementById('settings-gesture-zone');
    
    if (settingsPanel && !settingsPanel.contains(event.target) && 
        gestureZone && !gestureZone.contains(event.target)) {
      if (this.settingsPanel.close) {
        this.settingsPanel.close();
      }
    }
  }

  _handleKeyDown(event) {
    if (event.key === 'Escape' && this.settingsPanel && this.settingsPanel.isOpen) {
      if (this.settingsPanel.close) {
        this.settingsPanel.close();
      }
    }
  }

  _showDragIndicator() {
    const dragIndicator = document.getElementById('settings-drag-indicator');
    if (dragIndicator) {
      dragIndicator.style.opacity = '0.6';
    }
  }

  _hideDragIndicator() {
    const dragIndicator = document.getElementById('settings-drag-indicator');
    if (dragIndicator) {
      dragIndicator.style.opacity = '0';
    }
  }

  _resetGestureState() {
    this.gestureActive = false;
    this.isDragging = false;
    this.startY = 0;
    this.currentY = 0;
    this.panelTransitioning = false;
    this._hideDragIndicator();
  }

  // Mock utility methods
  simulateGesture(startY, endY, steps = 5) {
    return new Promise(async (resolve) => {
      if (this.gestureDelay > 0) {
        await new Promise(r => setTimeout(r, this.gestureDelay));
      }

      // Start gesture
      this.gestureActive = true;
      this.startY = startY;
      this._showDragIndicator();

      // Simulate move steps
      for (let i = 1; i <= steps; i++) {
        const progress = i / steps;
        const currentY = startY + (endY - startY) * progress;
        this.currentY = currentY;

        const dragDistance = currentY - startY;
        if (dragDistance >= this.dragThreshold && !this.isDragging) {
          this.isDragging = true;
          if (this.settingsPanel && this.settingsPanel.startReveal) {
            this.settingsPanel.startReveal();
          }
        }

        if (this.isDragging && this.settingsPanel && this.settingsPanel.updateReveal) {
          const maxDrag = 200;
          const percentage = Math.min(dragDistance / maxDrag, 1);
          this.settingsPanel.updateReveal(percentage);
        }

        await new Promise(r => setTimeout(r, 10));
      }

      // End gesture
      const dragDistance = endY - startY;
      const completionThreshold = this.dragThreshold * 2;

      if (this.isDragging) {
        if (dragDistance >= completionThreshold && this.settingsPanel && this.settingsPanel.open) {
          this.settingsPanel.open();
        } else if (this.settingsPanel && this.settingsPanel.cancelReveal) {
          this.settingsPanel.cancelReveal();
        }
      }

      this._resetGestureState();
      resolve();
    });
  }

  // Reset mock state
  reset() {
    this.isListening = false;
    this.gestureActive = false;
    this.isDragging = false;
    this.startY = 0;
    this.currentY = 0;
    this.panelTransitioning = false;
    this.shouldFailGesture = false;
    this.gestureDelay = 0;
    this.mockTouchSupport = true;

    // Clear mock calls
    Object.keys(this).forEach(key => {
      if (this[key] && typeof this[key].mockClear === 'function') {
        this[key].mockClear();
      }
    });
  }
}

// Factory function for creating mock instances
export const createMockGestureHandler = (settingsPanel) => new MockGestureHandler(settingsPanel);

// Default export
export default MockGestureHandler;