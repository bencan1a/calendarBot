/**
 * @fileoverview Mock implementation for SettingsAPI
 * Provides configurable mock responses for testing
 */

class MockSettingsAPI {
  constructor(config = {}) {
    this.baseURL = config.baseURL || '/api/settings';
    this.timeout = config.timeout || 10000;
    this.maxRetries = config.maxRetries || 3;
    this.retryDelay = config.retryDelay || 1000;
    
    // Mock state
    this.mockData = {};
    this.shouldFail = false;
    this.failureCount = 0;
    this.networkDelay = 0;
    
    // Spy on methods
    this.getSettings = jest.fn(this._getSettings.bind(this));
    this.updateSettings = jest.fn(this._updateSettings.bind(this));
    this.updateSetting = jest.fn(this._updateSetting.bind(this));
    this.createSettings = jest.fn(this._createSettings.bind(this));
    this.deleteSettings = jest.fn(this._deleteSettings.bind(this));
    this.deleteSetting = jest.fn(this._deleteSetting.bind(this));
    this.validateSettings = jest.fn(this._validateSettings.bind(this));
    this.validateSetting = jest.fn(this._validateSetting.bind(this));
  }

  // Mock configuration methods
  setMockData(data) {
    this.mockData = { ...data };
  }

  setShouldFail(shouldFail, count = 1) {
    this.shouldFail = shouldFail;
    this.failureCount = count;
  }

  setNetworkDelay(delay) {
    this.networkDelay = delay;
  }

  // Mock implementation methods
  async _getSettings() {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error('Network error');
    }
    
    return { ...this.mockData };
  }

  async _updateSettings(settings) {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error('Update failed');
    }
    
    this.mockData = { ...this.mockData, ...settings };
    return { ...this.mockData };
  }

  async _updateSetting(key, value) {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error(`Failed to update ${key}`);
    }
    
    this.mockData[key] = value;
    return value;
  }

  async _createSettings(settings) {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error('Create failed');
    }
    
    const newSettings = { ...settings, id: 'mock-id-' + Date.now() };
    this.mockData = { ...newSettings };
    return newSettings;
  }

  async _deleteSettings() {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error('Delete failed');
    }
    
    this.mockData = {};
    return { success: true };
  }

  async _deleteSetting(key) {
    await this._simulateNetworkDelay();
    
    if (this._shouldFailNow()) {
      throw new Error(`Failed to delete ${key}`);
    }
    
    delete this.mockData[key];
    return { deleted: key };
  }

  _validateSettings(settings) {
    if (this._shouldFailNow()) {
      throw new Error('Validation failed');
    }
    
    // Simple validation logic for testing
    const validKeys = ['theme', 'autoSave', 'refreshInterval', 'eventFilter'];
    
    for (const key of Object.keys(settings)) {
      if (!validKeys.includes(key)) {
        throw new Error(`Unknown setting key: ${key}`);
      }
    }
    
    return true;
  }

  _validateSetting(key, value) {
    if (this._shouldFailNow()) {
      throw new Error(`Invalid setting: ${key}`);
    }
    
    // Validation rules for testing
    const validationRules = {
      theme: (val) => ['dark', 'light', 'auto'].includes(val),
      autoSave: (val) => typeof val === 'boolean',
      refreshInterval: (val) => typeof val === 'number' && val >= 1 && val <= 60,
      eventFilter: (val) => Array.isArray(val) && val.every(item => typeof item === 'string')
    };
    
    const validator = validationRules[key];
    if (!validator) {
      throw new Error(`Unknown setting key: ${key}`);
    }
    
    if (!validator(value)) {
      throw new Error(`Invalid ${key} value`);
    }
    
    return true;
  }

  // Helper methods
  async _simulateNetworkDelay() {
    if (this.networkDelay > 0) {
      await new Promise(resolve => setTimeout(resolve, this.networkDelay));
    }
  }

  _shouldFailNow() {
    if (this.shouldFail && this.failureCount > 0) {
      this.failureCount--;
      return true;
    }
    return false;
  }

  // Reset mock state
  reset() {
    this.mockData = {};
    this.shouldFail = false;
    this.failureCount = 0;
    this.networkDelay = 0;
    
    // Clear mock calls
    this.getSettings.mockClear();
    this.updateSettings.mockClear();
    this.updateSetting.mockClear();
    this.createSettings.mockClear();
    this.deleteSettings.mockClear();
    this.deleteSetting.mockClear();
    this.validateSettings.mockClear();
    this.validateSetting.mockClear();
  }
}

// Factory function for creating mock instances
export const createMockSettingsAPI = (config) => new MockSettingsAPI(config);

// Default export
export default MockSettingsAPI;