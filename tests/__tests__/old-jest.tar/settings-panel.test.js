/**
 * @fileoverview Comprehensive test suite for settings-panel.js
 * Tests form functionality, auto-save, validation, and component integration
 */

describe('SettingsPanel - Form Functionality', () => {
  let settingsPanel;
  let mockSettingsAPI;
  let mockGestureHandler;
  let consoleLogSpy;
  let consoleErrorSpy;

  beforeEach(() => {
    // Reset DOM
    testUtils.cleanupDOM();
    testUtils.setupMockDOM(`
      <html>
        <head><title>CalendarBot</title></head>
        <body>
          <div class="settings-panel" id="settings-panel">
            <div class="settings-header">
              <h2>Settings</h2>
              <button class="settings-close" id="settings-close">×</button>
            </div>
            <div class="settings-content">
              <form id="settings-form" class="settings-form">
                <div class="form-group">
                  <label for="theme">Theme</label>
                  <select id="theme" name="theme">
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                    <option value="auto">Auto</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label for="auto-save">Auto-save</label>
                  <input type="checkbox" id="auto-save" name="autoSave">
                </div>
                
                <div class="form-group">
                  <label for="refresh-interval">Refresh Interval (minutes)</label>
                  <input type="number" id="refresh-interval" name="refreshInterval" min="1" max="60">
                </div>
                
                <div class="form-group">
                  <label>Event Filters</label>
                  <div class="event-filters" id="event-filters">
                    <div class="filter-list" id="filter-list"></div>
                    <div class="add-filter">
                      <input type="text" id="new-filter" placeholder="Add new filter">
                      <button type="button" id="add-filter-btn">Add</button>
                    </div>
                  </div>
                </div>
                
                <div class="form-actions">
                  <button type="submit" id="save-settings">Save</button>
                  <button type="button" id="reset-settings">Reset</button>
                </div>
              </form>
              
              <div class="settings-status" id="settings-status"></div>
            </div>
          </div>
        </body>
      </html>
    `);

    // Mock dependencies
    mockSettingsAPI = {
      getSettings: jest.fn(),
      updateSettings: jest.fn(),
      updateSetting: jest.fn(),
      validateSettings: jest.fn(),
      validateSetting: jest.fn()
    };

    mockGestureHandler = {
      initialize: jest.fn(),
      enable: jest.fn(),
      disable: jest.fn(),
      isListening: false
    };

    // Setup console spies
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

    // Load SettingsPanel
    require('../../calendarbot/web/static/shared/js/settings-panel.js');
    
    // Create instance
    settingsPanel = new window.SettingsPanel(mockSettingsAPI, mockGestureHandler);
  });

  afterEach(() => {
    if (settingsPanel) {
      settingsPanel.destroy();
    }
    jest.clearAllMocks();
    testUtils.cleanupDOM();
  });

  describe('Initialization', () => {
    it('should create SettingsPanel with default configuration', () => {
      expect(settingsPanel).toBeDefined();
      expect(settingsPanel.isOpen).toBe(false);
      expect(settingsPanel.autoSaveEnabled).toBe(true);
      expect(settingsPanel.autoSaveDelay).toBe(1000);
      expect(settingsPanel.isDirty).toBe(false);
    });

    it('should initialize form elements and event listeners', () => {
      settingsPanel.initialize();
      
      expect(settingsPanel.formElement).toBeDefined();
      expect(settingsPanel.formElement.tagName).toBe('FORM');
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Initialized with auto-save enabled');
    });

    it('should load initial settings from API', async () => {
      const mockSettings = {
        theme: 'dark',
        autoSave: true,
        refreshInterval: 30,
        eventFilter: ['work', 'personal']
      };

      mockSettingsAPI.getSettings.mockResolvedValue(mockSettings);
      
      await settingsPanel.initialize();
      
      expect(mockSettingsAPI.getSettings).toHaveBeenCalled();
      expect(settingsPanel.currentSettings).toEqual(mockSettings);
    });

    it('should populate form fields with loaded settings', async () => {
      const mockSettings = {
        theme: 'light',
        autoSave: false,
        refreshInterval: 15,
        eventFilter: ['work']
      };

      mockSettingsAPI.getSettings.mockResolvedValue(mockSettings);
      
      await settingsPanel.initialize();
      
      const themeSelect = document.getElementById('theme');
      const autoSaveCheckbox = document.getElementById('auto-save');
      const refreshInterval = document.getElementById('refresh-interval');
      
      expect(themeSelect.value).toBe('light');
      expect(autoSaveCheckbox.checked).toBe(false);
      expect(refreshInterval.value).toBe('15');
    });

    it('should handle API errors during initialization gracefully', async () => {
      mockSettingsAPI.getSettings.mockRejectedValue(new Error('Network error'));
      
      await settingsPanel.initialize();
      
      expect(consoleErrorSpy).toHaveBeenCalledWith('SettingsPanel: Failed to load settings:', expect.any(Error));
      expect(settingsPanel.currentSettings).toEqual({});
    });
  });

  describe('Form Field Management', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      await settingsPanel.initialize();
    });

    describe('Theme Selection', () => {
      it('should update theme setting on selection change', async () => {
        mockSettingsAPI.updateSetting.mockResolvedValue('light');
        
        const themeSelect = document.getElementById('theme');
        themeSelect.value = 'light';
        themeSelect.dispatchEvent(new Event('change'));
        
        // Wait for auto-save debounce
        await testUtils.waitForTimeout(1100);
        
        expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('theme', 'light');
        expect(settingsPanel.currentSettings.theme).toBe('light');
      });

      it('should validate theme values', () => {
        const themeSelect = document.getElementById('theme');
        
        themeSelect.value = 'dark';
        expect(settingsPanel.validateField('theme', 'dark')).toBe(true);
        
        themeSelect.value = 'invalid-theme';
        expect(settingsPanel.validateField('theme', 'invalid-theme')).toBe(false);
      });

      it('should show validation error for invalid theme', async () => {
        const themeSelect = document.getElementById('theme');
        themeSelect.value = 'invalid-theme';
        
        const changeEvent = new Event('change');
        themeSelect.dispatchEvent(changeEvent);
        
        await testUtils.waitForUpdates();
        
        const errorElement = themeSelect.parentElement.querySelector('.field-error');
        expect(errorElement).toBeTruthy();
        expect(errorElement.textContent).toContain('Invalid theme value');
      });
    });

    describe('Auto-save Toggle', () => {
      it('should update auto-save setting on checkbox change', async () => {
        mockSettingsAPI.updateSetting.mockResolvedValue(false);
        
        const autoSaveCheckbox = document.getElementById('auto-save');
        autoSaveCheckbox.checked = false;
        autoSaveCheckbox.dispatchEvent(new Event('change'));
        
        await testUtils.waitForTimeout(1100);
        
        expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('autoSave', false);
      });

      it('should disable auto-save functionality when unchecked', async () => {
        const autoSaveCheckbox = document.getElementById('auto-save');
        autoSaveCheckbox.checked = false;
        autoSaveCheckbox.dispatchEvent(new Event('change'));
        
        await testUtils.waitForUpdates();
        
        expect(settingsPanel.autoSaveEnabled).toBe(false);
        
        // Make another change that shouldn't auto-save
        const themeSelect = document.getElementById('theme');
        themeSelect.value = 'light';
        themeSelect.dispatchEvent(new Event('change'));
        
        await testUtils.waitForTimeout(1100);
        
        expect(mockSettingsAPI.updateSetting).toHaveBeenCalledTimes(1); // Only the autoSave change
      });
    });

    describe('Refresh Interval', () => {
      it('should update refresh interval on input change', async () => {
        mockSettingsAPI.updateSetting.mockResolvedValue(45);
        
        const refreshInput = document.getElementById('refresh-interval');
        refreshInput.value = '45';
        refreshInput.dispatchEvent(new Event('input'));
        
        await testUtils.waitForTimeout(1100);
        
        expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('refreshInterval', 45);
      });

      it('should validate refresh interval range', () => {
        expect(settingsPanel.validateField('refreshInterval', 30)).toBe(true);
        expect(settingsPanel.validateField('refreshInterval', 1)).toBe(true);
        expect(settingsPanel.validateField('refreshInterval', 60)).toBe(true);
        expect(settingsPanel.validateField('refreshInterval', 0)).toBe(false);
        expect(settingsPanel.validateField('refreshInterval', 61)).toBe(false);
        expect(settingsPanel.validateField('refreshInterval', -5)).toBe(false);
      });

      it('should show error for out-of-range values', async () => {
        const refreshInput = document.getElementById('refresh-interval');
        refreshInput.value = '120';
        refreshInput.dispatchEvent(new Event('input'));
        
        await testUtils.waitForUpdates();
        
        const errorElement = refreshInput.parentElement.querySelector('.field-error');
        expect(errorElement).toBeTruthy();
        expect(errorElement.textContent).toContain('must be between 1 and 60');
      });
    });
  });

  describe('Event Filter Management', () => {
    beforeEach(async () => {
      const mockSettings = {
        eventFilter: ['work', 'personal']
      };
      mockSettingsAPI.getSettings.mockResolvedValue(mockSettings);
      await settingsPanel.initialize();
    });

    it('should render existing event filters', () => {
      const filterList = document.getElementById('filter-list');
      const filterItems = filterList.querySelectorAll('.filter-item');
      
      expect(filterItems).toHaveLength(2);
      expect(filterItems[0].textContent).toContain('work');
      expect(filterItems[1].textContent).toContain('personal');
    });

    it('should add new event filter', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'family']);
      
      const newFilterInput = document.getElementById('new-filter');
      const addButton = document.getElementById('add-filter-btn');
      
      newFilterInput.value = 'family';
      addButton.click();
      
      await testUtils.waitForTimeout(1100);
      
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('eventFilter', ['work', 'personal', 'family']);
      
      const filterList = document.getElementById('filter-list');
      const filterItems = filterList.querySelectorAll('.filter-item');
      expect(filterItems).toHaveLength(3);
    });

    it('should remove event filter on delete button click', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['personal']);
      
      const filterList = document.getElementById('filter-list');
      const firstFilterItem = filterList.querySelector('.filter-item');
      const deleteButton = firstFilterItem.querySelector('.filter-delete');
      
      deleteButton.click();
      
      await testUtils.waitForTimeout(1100);
      
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('eventFilter', ['personal']);
    });

    it('should prevent adding duplicate filters', async () => {
      const newFilterInput = document.getElementById('new-filter');
      const addButton = document.getElementById('add-filter-btn');
      
      newFilterInput.value = 'work'; // Duplicate
      addButton.click();
      
      await testUtils.waitForUpdates();
      
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Filter already exists');
      expect(mockSettingsAPI.updateSetting).not.toHaveBeenCalled();
    });

    it('should prevent adding empty filters', async () => {
      const newFilterInput = document.getElementById('new-filter');
      const addButton = document.getElementById('add-filter-btn');
      
      newFilterInput.value = ''; // Empty
      addButton.click();
      
      await testUtils.waitForUpdates();
      
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Filter name cannot be empty');
      expect(mockSettingsAPI.updateSetting).not.toHaveBeenCalled();
    });

    it('should add filter on Enter key press', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'sports']);
      
      const newFilterInput = document.getElementById('new-filter');
      newFilterInput.value = 'sports';
      
      const enterEvent = new KeyboardEvent('keydown', { key: 'Enter' });
      newFilterInput.dispatchEvent(enterEvent);
      
      await testUtils.waitForTimeout(1100);
      
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('eventFilter', ['work', 'personal', 'sports']);
    });

    it('should clear input after successful filter addition', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'travel']);
      
      const newFilterInput = document.getElementById('new-filter');
      const addButton = document.getElementById('add-filter-btn');
      
      newFilterInput.value = 'travel';
      addButton.click();
      
      await testUtils.waitForTimeout(1100);
      
      expect(newFilterInput.value).toBe('');
    });
  });

  describe('Auto-save Functionality', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({ autoSave: true });
      await settingsPanel.initialize();
    });

    it('should debounce auto-save calls', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('dark');
      
      const themeSelect = document.getElementById('theme');
      
      // Rapid changes
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      themeSelect.value = 'auto';
      themeSelect.dispatchEvent(new Event('change'));
      
      // Wait for debounce
      await testUtils.waitForTimeout(1100);
      
      // Only the last change should be saved
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledTimes(1);
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('theme', 'auto');
    });

    it('should show saving indicator during auto-save', async () => {
      mockSettingsAPI.updateSetting.mockImplementation(() => 
        new Promise(resolve => setTimeout(() => resolve('dark'), 500))
      );
      
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      // Check for saving indicator
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Saving...');
      
      // Wait for save to complete
      await testUtils.waitForTimeout(600);
      
      expect(statusElement.textContent).toContain('Saved');
    });

    it('should handle auto-save errors gracefully', async () => {
      mockSettingsAPI.updateSetting.mockRejectedValue(new Error('Network error'));
      
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Error saving settings');
      expect(consoleErrorSpy).toHaveBeenCalledWith('SettingsPanel: Auto-save failed:', expect.any(Error));
    });

    it('should mark form as dirty when changes are made', () => {
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      expect(settingsPanel.isDirty).toBe(true);
    });

    it('should clear dirty flag after successful save', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('dark');
      
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      expect(settingsPanel.isDirty).toBe(true);
      
      await testUtils.waitForTimeout(1100);
      
      expect(settingsPanel.isDirty).toBe(false);
    });
  });

  describe('Form Validation', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      await settingsPanel.initialize();
    });

    it('should validate all fields before manual save', async () => {
      const saveButton = document.getElementById('save-settings');
      
      // Set invalid values
      const themeSelect = document.getElementById('theme');
      const refreshInput = document.getElementById('refresh-interval');
      
      themeSelect.value = 'invalid-theme';
      refreshInput.value = '120';
      
      saveButton.click();
      
      await testUtils.waitForUpdates();
      
      // Should show validation errors
      const themeError = themeSelect.parentElement.querySelector('.field-error');
      const refreshError = refreshInput.parentElement.querySelector('.field-error');
      
      expect(themeError).toBeTruthy();
      expect(refreshError).toBeTruthy();
      expect(mockSettingsAPI.updateSettings).not.toHaveBeenCalled();
    });

    it('should save valid form data on manual save', async () => {
      mockSettingsAPI.updateSettings.mockResolvedValue({
        theme: 'dark',
        autoSave: true,
        refreshInterval: 30
      });
      
      const saveButton = document.getElementById('save-settings');
      const themeSelect = document.getElementById('theme');
      const autoSaveCheckbox = document.getElementById('auto-save');
      const refreshInput = document.getElementById('refresh-interval');
      
      themeSelect.value = 'dark';
      autoSaveCheckbox.checked = true;
      refreshInput.value = '30';
      
      saveButton.click();
      
      await testUtils.waitForUpdates();
      
      expect(mockSettingsAPI.updateSettings).toHaveBeenCalledWith({
        theme: 'dark',
        autoSave: true,
        refreshInterval: 30,
        eventFilter: []
      });
    });

    it('should clear validation errors when field becomes valid', async () => {
      const themeSelect = document.getElementById('theme');
      
      // Set invalid value
      themeSelect.value = 'invalid-theme';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      let errorElement = themeSelect.parentElement.querySelector('.field-error');
      expect(errorElement).toBeTruthy();
      
      // Set valid value
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      errorElement = themeSelect.parentElement.querySelector('.field-error');
      expect(errorElement).toBeFalsy();
    });
  });

  describe('Form Reset Functionality', () => {
    beforeEach(async () => {
      const mockSettings = {
        theme: 'dark',
        autoSave: true,
        refreshInterval: 30,
        eventFilter: ['work']
      };
      mockSettingsAPI.getSettings.mockResolvedValue(mockSettings);
      await settingsPanel.initialize();
    });

    it('should reset form to original values', () => {
      const resetButton = document.getElementById('reset-settings');
      const themeSelect = document.getElementById('theme');
      const autoSaveCheckbox = document.getElementById('auto-save');
      
      // Make changes
      themeSelect.value = 'light';
      autoSaveCheckbox.checked = false;
      
      resetButton.click();
      
      // Should revert to original values
      expect(themeSelect.value).toBe('dark');
      expect(autoSaveCheckbox.checked).toBe(true);
    });

    it('should clear dirty flag on reset', () => {
      const resetButton = document.getElementById('reset-settings');
      const themeSelect = document.getElementById('theme');
      
      // Make change to set dirty flag
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      expect(settingsPanel.isDirty).toBe(true);
      
      resetButton.click();
      
      expect(settingsPanel.isDirty).toBe(false);
    });

    it('should clear validation errors on reset', () => {
      const resetButton = document.getElementById('reset-settings');
      const themeSelect = document.getElementById('theme');
      
      // Set invalid value to trigger error
      themeSelect.value = 'invalid-theme';
      themeSelect.dispatchEvent(new Event('change'));
      
      resetButton.click();
      
      const errorElement = themeSelect.parentElement.querySelector('.field-error');
      expect(errorElement).toBeFalsy();
    });
  });

  describe('Panel State Management', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      await settingsPanel.initialize();
    });

    it('should open panel with animation', async () => {
      settingsPanel.open();
      
      expect(settingsPanel.isOpen).toBe(true);
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Opening panel');
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('open')).toBe(true);
    });

    it('should close panel with animation', async () => {
      settingsPanel.open();
      settingsPanel.close();
      
      expect(settingsPanel.isOpen).toBe(false);
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Closing panel');
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('open')).toBe(false);
    });

    it('should warn about unsaved changes when closing dirty form', () => {
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      // Mock confirm dialog
      const confirmSpy = jest.spyOn(window, 'confirm').mockReturnValue(false);
      
      settingsPanel.close();
      
      expect(confirmSpy).toHaveBeenCalledWith('You have unsaved changes. Close anyway?');
      expect(settingsPanel.isOpen).toBe(false); // Should still close if user cancels
      
      confirmSpy.mockRestore();
    });

    it('should close panel on close button click', () => {
      settingsPanel.open();
      
      const closeButton = document.getElementById('settings-close');
      closeButton.click();
      
      expect(settingsPanel.isOpen).toBe(false);
    });

    it('should enable gesture handler when opening', () => {
      settingsPanel.open();
      
      expect(mockGestureHandler.enable).toHaveBeenCalled();
    });

    it('should disable gesture handler when closing', () => {
      settingsPanel.open();
      settingsPanel.close();
      
      expect(mockGestureHandler.disable).toHaveBeenCalled();
    });
  });

  describe('Integration and Error Handling', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      await settingsPanel.initialize();
    });

    /**
     * Test complete workflow from form change to API save
     * Simulates real user interaction with proper timing
     */
    it('should handle complete form interaction workflow', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('dark');
      
      // User opens panel
      settingsPanel.open();
      
      // User changes theme
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      // Auto-save should trigger
      await testUtils.waitForTimeout(1100);
      
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('theme', 'dark');
      expect(settingsPanel.currentSettings.theme).toBe('dark');
      expect(settingsPanel.isDirty).toBe(false);
      
      // User closes panel
      settingsPanel.close();
      
      expect(settingsPanel.isOpen).toBe(false);
    });

    it('should handle API validation errors gracefully', async () => {
      mockSettingsAPI.updateSetting.mockRejectedValue(new Error('Validation failed: Invalid theme'));
      
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Error saving settings');
      expect(statusElement.classList.contains('error')).toBe(true);
    });

    it('should handle network timeouts during save', async () => {
      mockSettingsAPI.updateSetting.mockImplementation(() => 
        new Promise((resolve, reject) => {
          setTimeout(() => reject(new Error('Network timeout')), 2000);
        })
      );
      
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      // Should show saving state
      const statusElement = document.getElementById('settings-status');
      expect(statusElement.textContent).toContain('Saving...');
      
      // Wait for timeout
      await testUtils.waitForTimeout(2100);
      
      expect(statusElement.textContent).toContain('Error saving settings');
    });

    it('should prevent multiple simultaneous saves', async () => {
      mockSettingsAPI.updateSetting.mockImplementation(() => 
        new Promise(resolve => setTimeout(() => resolve('dark'), 1000))
      );
      
      const themeSelect = document.getElementById('theme');
      
      // Trigger first save
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      // Trigger second save while first is in progress
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100);
      
      // Wait for both to complete
      await testUtils.waitForTimeout(2000);
      
      // Should have been called twice but not simultaneously
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledTimes(2);
    });
  });

  describe('Cleanup and Destruction', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      await settingsPanel.initialize();
    });

    it('should clean up event listeners on destroy', () => {
      const formElement = settingsPanel.formElement;
      const listenerCount = formElement.addEventListener.mock ? formElement.addEventListener.mock.calls.length : 0;
      
      settingsPanel.destroy();
      
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Cleaned up and destroyed');
    });

    it('should cancel pending auto-saves on destroy', () => {
      const themeSelect = document.getElementById('theme');
      themeSelect.value = 'dark';
      themeSelect.dispatchEvent(new Event('change'));
      
      // Destroy before auto-save triggers
      settingsPanel.destroy();
      
      // Wait for potential auto-save
      setTimeout(() => {
        expect(mockSettingsAPI.updateSetting).not.toHaveBeenCalled();
      }, 1100);
    });

    it('should disable gesture handler on destroy', () => {
      settingsPanel.destroy();
      
      expect(mockGestureHandler.disable).toHaveBeenCalled();
    });
  });
});