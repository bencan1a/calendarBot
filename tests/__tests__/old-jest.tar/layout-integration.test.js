/**
 * @fileoverview Comprehensive test suite for layout integration with settings panel
 * Tests cross-layout compatibility, layout-specific configurations, and layout switching
 */

describe('Layout Integration - Cross-Layout Compatibility', () => {
  let mockSettingsAPI;
  let mockGestureHandler;
  let consoleLogSpy;
  let consoleErrorSpy;

  const mockLayouts = {
    '3x4': null,
    '4x8': null,
    'whats-next-view': null
  };

  beforeEach(() => {
    // Reset DOM
    testUtils.cleanupDOM();
    
    // Setup console spies
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

    // Mock dependencies
    mockSettingsAPI = {
      getSettings: jest.fn(),
      updateSettings: jest.fn(),
      updateSetting: jest.fn(),
      validateSettings: jest.fn(),
      validateSetting: jest.fn()
    };

    mockGestureHandler = {
      initialize: jest.fn(),
      enable: jest.fn(),
      disable: jest.fn(),
      isListening: false,
      updateGestureZoneHeight: jest.fn()
    };

    // Load required modules
    require('../../calendarbot/web/static/shared/js/settings-api.js');
    require('../../calendarbot/web/static/shared/js/gesture-handler.js');
    require('../../calendarbot/web/static/shared/js/settings-panel.js');
  });

  afterEach(() => {
    // Cleanup layouts
    Object.keys(mockLayouts).forEach(layoutName => {
      if (mockLayouts[layoutName]) {
        mockLayouts[layoutName].destroy?.();
        mockLayouts[layoutName] = null;
      }
    });
    
    jest.clearAllMocks();
    testUtils.cleanupDOM();
  });

  describe('3x4 Layout Integration', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot 3x4</title></head>
          <body>
            <div class="layout-3x4" id="layout-container">
              <div class="grid-container">
                ${Array.from({length: 12}, (_, i) => `
                  <div class="grid-cell" data-cell="${i}">
                    <div class="event-content">Event ${i + 1}</div>
                  </div>
                `).join('')}
              </div>
              
              <div class="settings-panel" id="settings-panel">
                <div class="settings-header">
                  <h2>Settings</h2>
                  <button class="settings-close">×</button>
                </div>
                <div class="settings-content">
                  <form id="settings-form" class="settings-form">
                    <div class="form-group">
                      <label for="theme">Theme</label>
                      <select id="theme" name="theme">
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="grid-size">Grid Size</label>
                      <select id="grid-size" name="gridSize">
                        <option value="3x4">3x4</option>
                        <option value="4x8">4x8</option>
                      </select>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </body>
        </html>
      `);

      // Load 3x4 layout
      require('../../calendarbot/web/static/layouts/3x4/3x4.js');
    });

    it('should initialize settings panel within 3x4 layout', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        theme: 'dark',
        gridSize: '3x4'
      });

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      expect(mockLayouts['3x4'].settingsPanel).toBeDefined();
      expect(mockSettingsAPI.getSettings).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalledWith('Layout3x4: Initialized with settings panel integration');
    });

    it('should apply 3x4-specific settings correctly', async () => {
      const layout3x4Settings = {
        theme: 'dark',
        gridSize: '3x4',
        cellSpacing: 2,
        showGridNumbers: true
      };

      mockSettingsAPI.getSettings.mockResolvedValue(layout3x4Settings);

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();
      mockLayouts['3x4'].applySettings(layout3x4Settings);

      const gridContainer = document.querySelector('.grid-container');
      expect(gridContainer.style.gap).toBe('2px');
      expect(gridContainer.classList.contains('show-numbers')).toBe(true);
    });

    it('should handle grid size changes in 3x4 layout', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('4x8');

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      // Simulate grid size change
      const gridSizeSelect = document.getElementById('grid-size');
      gridSizeSelect.value = '4x8';
      gridSizeSelect.dispatchEvent(new Event('change'));

      await testUtils.waitForTimeout(100);

      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('gridSize', '4x8');
      expect(consoleLogSpy).toHaveBeenCalledWith('Layout3x4: Grid size changed to 4x8, switching layout');
    });

    it('should adjust gesture zone height for 3x4 layout', async () => {
      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      expect(mockGestureHandler.updateGestureZoneHeight).toHaveBeenCalledWith(40); // 3x4 specific height
    });

    it('should handle 3x4 layout-specific event filters', async () => {
      const settingsWithFilters = {
        eventFilter: ['work', 'personal'],
        gridViewMode: 'compact'
      };

      mockSettingsAPI.getSettings.mockResolvedValue(settingsWithFilters);
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'meetings']);

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      // Test filter application
      await mockLayouts['3x4'].applyEventFilters(['work', 'personal', 'meetings']);

      const visibleCells = document.querySelectorAll('.grid-cell:not(.filtered)');
      expect(visibleCells.length).toBeGreaterThan(0);
    });
  });

  describe('4x8 Layout Integration', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot 4x8</title></head>
          <body>
            <div class="layout-4x8" id="layout-container">
              <div class="grid-container">
                ${Array.from({length: 32}, (_, i) => `
                  <div class="grid-cell" data-cell="${i}">
                    <div class="event-content">Event ${i + 1}</div>
                  </div>
                `).join('')}
              </div>
              
              <div class="settings-panel" id="settings-panel">
                <div class="settings-header">
                  <h2>Settings</h2>
                  <button class="settings-close">×</button>
                </div>
                <div class="settings-content">
                  <form id="settings-form" class="settings-form">
                    <div class="form-group">
                      <label for="theme">Theme</label>
                      <select id="theme" name="theme">
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="grid-density">Grid Density</label>
                      <select id="grid-density" name="gridDensity">
                        <option value="normal">Normal</option>
                        <option value="compact">Compact</option>
                        <option value="spacious">Spacious</option>
                      </select>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </body>
        </html>
      `);

      // Load 4x8 layout
      require('../../calendarbot/web/static/layouts/4x8/4x8.js');
    });

    it('should initialize settings panel within 4x8 layout', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        theme: 'light',
        gridDensity: 'normal'
      });

      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['4x8'].initialize();

      expect(mockLayouts['4x8'].settingsPanel).toBeDefined();
      expect(mockSettingsAPI.getSettings).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalledWith('Layout4x8: Initialized with settings panel integration');
    });

    it('should apply 4x8-specific density settings', async () => {
      const layout4x8Settings = {
        theme: 'light',
        gridDensity: 'compact',
        showTimeLabels: false
      };

      mockSettingsAPI.getSettings.mockResolvedValue(layout4x8Settings);

      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['4x8'].initialize();
      mockLayouts['4x8'].applySettings(layout4x8Settings);

      const gridContainer = document.querySelector('.grid-container');
      expect(gridContainer.classList.contains('density-compact')).toBe(true);
      expect(gridContainer.classList.contains('hide-time-labels')).toBe(true);
    });

    it('should handle grid density changes in 4x8 layout', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('spacious');

      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['4x8'].initialize();

      const densitySelect = document.getElementById('grid-density');
      densitySelect.value = 'spacious';
      densitySelect.dispatchEvent(new Event('change'));

      await testUtils.waitForTimeout(100);

      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('gridDensity', 'spacious');
    });

    it('should adjust gesture zone height for 4x8 layout', async () => {
      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['4x8'].initialize();

      expect(mockGestureHandler.updateGestureZoneHeight).toHaveBeenCalledWith(60); // 4x8 specific height
    });

    it('should handle 4x8 layout scrolling with settings panel open', async () => {
      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['4x8'].initialize();

      // Open settings panel
      mockLayouts['4x8'].settingsPanel.open();

      // Test scroll behavior
      const scrollEvent = new Event('scroll');
      document.dispatchEvent(scrollEvent);

      // Should not close panel during normal scroll
      expect(mockLayouts['4x8'].settingsPanel.isOpen).toBe(true);
    });
  });

  describe('What\'s Next View Layout Integration', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot What's Next</title></head>
          <body>
            <div class="layout-whats-next" id="layout-container">
              <div class="time-display">
                <div class="current-time">12:00 PM</div>
                <div class="current-date">Monday, July 18</div>
              </div>
              
              <div class="events-list">
                <div class="event-item">
                  <div class="event-time">1:00 PM</div>
                  <div class="event-title">Meeting</div>
                </div>
                <div class="event-item">
                  <div class="event-time">3:00 PM</div>
                  <div class="event-title">Appointment</div>
                </div>
              </div>
              
              <div class="settings-panel" id="settings-panel">
                <div class="settings-header">
                  <h2>Settings</h2>
                  <button class="settings-close">×</button>
                </div>
                <div class="settings-content">
                  <form id="settings-form" class="settings-form">
                    <div class="form-group">
                      <label for="time-format">Time Format</label>
                      <select id="time-format" name="timeFormat">
                        <option value="12">12-hour</option>
                        <option value="24">24-hour</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="upcoming-count">Upcoming Events Count</label>
                      <input type="number" id="upcoming-count" name="upcomingCount" min="1" max="10">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </body>
        </html>
      `);

      // Load what's next view layout
      require('../../calendarbot/web/static/layouts/whats-next-view/whats-next-view.js');
    });

    it('should initialize settings panel within what\'s next view layout', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        timeFormat: '12',
        upcomingCount: 5
      });

      mockLayouts['whats-next-view'] = new window.WhatsNextView({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['whats-next-view'].initialize();

      expect(mockLayouts['whats-next-view'].settingsPanel).toBeDefined();
      expect(mockSettingsAPI.getSettings).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalledWith('WhatsNextView: Initialized with settings panel integration');
    });

    it('should apply what\'s next view specific settings', async () => {
      const whatsNextSettings = {
        timeFormat: '24',
        upcomingCount: 3,
        showCurrentTime: true,
        autoRefresh: true
      };

      mockSettingsAPI.getSettings.mockResolvedValue(whatsNextSettings);

      mockLayouts['whats-next-view'] = new window.WhatsNextView({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['whats-next-view'].initialize();
      mockLayouts['whats-next-view'].applySettings(whatsNextSettings);

      const timeDisplay = document.querySelector('.current-time');
      expect(timeDisplay.dataset.format).toBe('24');
      
      const eventItems = document.querySelectorAll('.event-item');
      expect(eventItems.length).toBeLessThanOrEqual(3);
    });

    it('should handle time format changes in what\'s next view', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('24');

      mockLayouts['whats-next-view'] = new window.WhatsNextView({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['whats-next-view'].initialize();

      const timeFormatSelect = document.getElementById('time-format');
      timeFormatSelect.value = '24';
      timeFormatSelect.dispatchEvent(new Event('change'));

      await testUtils.waitForTimeout(100);

      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('timeFormat', '24');
    });

    it('should adjust gesture zone height for what\'s next view layout', async () => {
      mockLayouts['whats-next-view'] = new window.WhatsNextView({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['whats-next-view'].initialize();

      expect(mockGestureHandler.updateGestureZoneHeight).toHaveBeenCalledWith(45); // WhatsNext specific height
    });

    it('should handle auto-refresh with settings panel', async () => {
      const mockDate = new Date('2024-07-18T12:00:00');
      jest.spyOn(global, 'Date').mockImplementation(() => mockDate);

      mockLayouts['whats-next-view'] = new window.WhatsNextView({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['whats-next-view'].initialize();

      // Enable auto-refresh
      mockLayouts['whats-next-view'].startAutoRefresh(5000);

      // Open settings panel
      mockLayouts['whats-next-view'].settingsPanel.open();

      // Auto-refresh should continue even with panel open
      await testUtils.waitForTimeout(100);
      
      expect(mockLayouts['whats-next-view'].autoRefreshEnabled).toBe(true);

      global.Date.mockRestore();
    });
  });

  describe('Cross-Layout Compatibility', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot</title></head>
          <body>
            <div id="layout-switcher">
              <button id="switch-3x4">3x4</button>
              <button id="switch-4x8">4x8</button>
              <button id="switch-whats-next">What's Next</button>
            </div>
            <div id="layout-container"></div>
          </body>
        </html>
      `);
    });

    /**
     * Test settings persistence when switching between layouts
     * Ensures user preferences are maintained across layout changes
     */
    it('should persist settings when switching between layouts', async () => {
      const commonSettings = {
        theme: 'dark',
        eventFilter: ['work', 'personal'],
        autoSave: true
      };

      const layout3x4Settings = {
        ...commonSettings,
        gridSize: '3x4',
        cellSpacing: 2
      };

      const layout4x8Settings = {
        ...commonSettings,
        gridDensity: 'compact',
        showTimeLabels: false
      };

      mockSettingsAPI.getSettings.mockResolvedValue(commonSettings);
      mockSettingsAPI.updateSettings.mockResolvedValue(layout4x8Settings);

      // Start with 3x4 layout
      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['3x4'].initialize();

      // Switch to 4x8 layout
      mockLayouts['3x4'].destroy();
      
      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['4x8'].initialize();

      // Verify settings persistence
      expect(mockSettingsAPI.getSettings).toHaveBeenCalledTimes(2);
      expect(mockLayouts['4x8'].currentSettings.theme).toBe('dark');
      expect(mockLayouts['4x8'].currentSettings.eventFilter).toEqual(['work', 'personal']);
    });

    it('should handle layout-specific settings migration', async () => {
      const legacySettings = {
        theme: 'dark',
        gridConfig: '3x4', // Old format
        filters: ['work'] // Old format
      };

      const migratedSettings = {
        theme: 'dark',
        gridSize: '3x4', // New format
        eventFilter: ['work'] // New format
      };

      mockSettingsAPI.getSettings.mockResolvedValue(legacySettings);
      mockSettingsAPI.updateSettings.mockResolvedValue(migratedSettings);

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      // Should trigger settings migration
      expect(mockSettingsAPI.updateSettings).toHaveBeenCalledWith(migratedSettings);
      expect(consoleLogSpy).toHaveBeenCalledWith('Layout3x4: Migrated legacy settings format');
    });

    it('should handle gesture handler sharing between layouts', async () => {
      // Initialize first layout
      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['3x4'].initialize();

      expect(mockGestureHandler.initialize).toHaveBeenCalledTimes(1);

      // Switch to second layout with same gesture handler
      mockLayouts['3x4'].destroy();
      
      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['4x8'].initialize();

      // Should reuse gesture handler, not reinitialize
      expect(mockGestureHandler.initialize).toHaveBeenCalledTimes(1);
      expect(mockGestureHandler.updateGestureZoneHeight).toHaveBeenCalledWith(60);
    });

    it('should handle settings panel state during layout switching', async () => {
      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['3x4'].initialize();

      // Open settings panel
      mockLayouts['3x4'].settingsPanel.open();
      expect(mockLayouts['3x4'].settingsPanel.isOpen).toBe(true);

      // Switch layouts while panel is open
      const wasPanelOpen = mockLayouts['3x4'].settingsPanel.isOpen;
      mockLayouts['3x4'].destroy();

      mockLayouts['4x8'] = new window.Layout4x8({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['4x8'].initialize();

      // New layout should respect previous panel state
      if (wasPanelOpen) {
        mockLayouts['4x8'].settingsPanel.open();
      }

      expect(mockLayouts['4x8'].settingsPanel.isOpen).toBe(wasPanelOpen);
    });
  });

  describe('Layout-Specific Error Handling', () => {
    it('should handle layout initialization failures gracefully', async () => {
      mockSettingsAPI.getSettings.mockRejectedValue(new Error('Settings API unavailable'));

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      expect(consoleErrorSpy).toHaveBeenCalledWith('Layout3x4: Failed to initialize settings:', expect.any(Error));
      // Should continue with default settings
      expect(mockLayouts['3x4'].currentSettings).toEqual({});
    });

    it('should handle settings panel creation failures', async () => {
      // Mock settings panel constructor to fail
      const originalSettingsPanel = window.SettingsPanel;
      window.SettingsPanel = jest.fn().mockImplementation(() => {
        throw new Error('Settings panel creation failed');
      });

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      expect(consoleErrorSpy).toHaveBeenCalledWith('Layout3x4: Failed to create settings panel:', expect.any(Error));
      expect(mockLayouts['3x4'].settingsPanel).toBeNull();

      // Restore original constructor
      window.SettingsPanel = originalSettingsPanel;
    });

    it('should handle gesture handler failures', async () => {
      mockGestureHandler.initialize.mockImplementation(() => {
        throw new Error('Gesture handler initialization failed');
      });

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });

      await mockLayouts['3x4'].initialize();

      expect(consoleErrorSpy).toHaveBeenCalledWith('Layout3x4: Gesture handler failed:', expect.any(Error));
      // Layout should continue without gesture support
      expect(mockLayouts['3x4'].gestureEnabled).toBe(false);
    });
  });

  describe('Performance and Resource Management', () => {
    it('should properly cleanup resources when destroying layouts', async () => {
      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['3x4'].initialize();

      const settingsPanel = mockLayouts['3x4'].settingsPanel;
      const destroySpy = jest.spyOn(settingsPanel, 'destroy');

      mockLayouts['3x4'].destroy();

      expect(destroySpy).toHaveBeenCalled();
      expect(mockGestureHandler.disable).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalledWith('Layout3x4: Cleaned up and destroyed');
    });

    it('should handle memory-efficient layout switching', async () => {
      const performanceMarkSpy = jest.spyOn(performance, 'mark').mockImplementation();
      const performanceMeasureSpy = jest.spyOn(performance, 'measure').mockImplementation();

      // Rapid layout switching test
      for (let i = 0; i < 3; i++) {
        mockLayouts['3x4'] = new window.Layout3x4({
          settingsAPI: mockSettingsAPI,
          gestureHandler: mockGestureHandler
        });
        await mockLayouts['3x4'].initialize();
        mockLayouts['3x4'].destroy();
      }

      expect(performanceMarkSpy).toHaveBeenCalled();
      expect(performanceMeasureSpy).toHaveBeenCalled();

      performanceMarkSpy.mockRestore();
      performanceMeasureSpy.mockRestore();
    });

    it('should throttle settings updates during rapid layout changes', async () => {
      let updateCount = 0;
      mockSettingsAPI.updateSetting.mockImplementation(() => {
        updateCount++;
        return Promise.resolve('updated');
      });

      mockLayouts['3x4'] = new window.Layout3x4({
        settingsAPI: mockSettingsAPI,
        gestureHandler: mockGestureHandler
      });
      await mockLayouts['3x4'].initialize();

      // Rapid setting changes
      for (let i = 0; i < 10; i++) {
        mockLayouts['3x4'].settingsPanel.updateSetting('theme', `theme-${i}`);
      }

      await testUtils.waitForTimeout(1200); // Wait for debounce

      // Should be throttled to prevent excessive API calls
      expect(updateCount).toBeLessThan(10);
    });
  });
});