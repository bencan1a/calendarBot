/**
 * @fileoverview Comprehensive test utilities for CalendarBot browser tests
 * Provides DOM manipulation, event simulation, and testing helpers
 */

// Global test utilities available to all test files
window.testUtils = {
  /**
   * Setup a mock DOM environment for testing
   * @param {string} htmlContent - HTML content to setup in document body
   */
  setupMockDOM(htmlContent) {
    // Clean existing DOM first
    document.head.innerHTML = '';
    document.body.innerHTML = '';
    
    // Parse and setup new DOM
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');
    
    // Copy head content
    Array.from(doc.head.children).forEach(child => {
      document.head.appendChild(child.cloneNode(true));
    });
    
    // Copy body content
    Array.from(doc.body.children).forEach(child => {
      document.body.appendChild(child.cloneNode(true));
    });
  },

  /**
   * Clean up DOM and reset global state
   */
  cleanupDOM() {
    document.head.innerHTML = '';
    document.body.innerHTML = '';
    
    // Reset window properties
    delete window.GestureHandler;
    delete window.SettingsAPI;
    delete window.SettingsPanel;
    delete window.Layout3x4;
    delete window.Layout4x8;
    delete window.WhatsNextView;
    
    // Clear any existing timers
    jest.clearAllTimers();
  },

  /**
   * Set viewport size for responsive testing
   * @param {number} width - Viewport width
   * @param {number} height - Viewport height
   */
  setViewportSize(width, height) {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: width,
    });
    Object.defineProperty(window, 'innerHeight', {
      writable: true,
      configurable: true,
      value: height,
    });
    
    // Trigger resize event
    window.dispatchEvent(new Event('resize'));
  },

  /**
   * Mock touch device environment
   */
  setupMockTouchDevice() {
    Object.defineProperty(window, 'ontouchstart', {
      writable: true,
      configurable: true,
      value: null,
    });
    
    Object.defineProperty(navigator, 'maxTouchPoints', {
      writable: true,
      configurable: true,
      value: 10,
    });
  },

  /**
   * Simulate keyboard key press events
   * @param {string} key - Key to press
   * @param {Object} options - Additional event options
   */
  pressKey(key, options = {}) {
    const keyEvent = new KeyboardEvent('keydown', {
      key,
      code: key,
      bubbles: true,
      ...options
    });
    
    const activeElement = document.activeElement || document.body;
    activeElement.dispatchEvent(keyEvent);
    
    // Also dispatch keyup for completeness
    const keyUpEvent = new KeyboardEvent('keyup', {
      key,
      code: key,
      bubbles: true,
      ...options
    });
    activeElement.dispatchEvent(keyUpEvent);
  },

  /**
   * Wait for a specific timeout
   * @param {number} ms - Milliseconds to wait
   * @returns {Promise}
   */
  waitForTimeout(ms) {
    return new Promise(resolve => {
      setTimeout(resolve, ms);
    });
  },

  /**
   * Wait for DOM updates and next tick
   * @returns {Promise}
   */
  waitForUpdates() {
    return new Promise(resolve => {
      requestAnimationFrame(() => {
        setTimeout(resolve, 0);
      });
    });
  },

  /**
   * Create a mock fetch response
   * @param {any} data - Response data
   * @param {number} status - HTTP status code
   * @param {boolean} ok - Response ok status
   * @returns {Object} Mock response object
   */
  createMockResponse(data, status = 200, ok = true) {
    return {
      ok,
      status,
      statusText: status === 200 ? 'OK' : 'Error',
      json: jest.fn().mockResolvedValue(data),
      text: jest.fn().mockResolvedValue(JSON.stringify(data)),
      headers: new Headers({ 'Content-Type': 'application/json' })
    };
  },

  /**
   * Create a mock settings API with default methods
   * @param {Object} overrides - Method overrides
   * @returns {Object} Mock settings API
   */
  createMockSettingsAPI(overrides = {}) {
    return {
      getSettings: jest.fn().mockResolvedValue({}),
      updateSettings: jest.fn().mockResolvedValue({}),
      updateSetting: jest.fn().mockResolvedValue(true),
      createSettings: jest.fn().mockResolvedValue({}),
      deleteSettings: jest.fn().mockResolvedValue({}),
      deleteSetting: jest.fn().mockResolvedValue({}),
      validateSettings: jest.fn().mockReturnValue(true),
      validateSetting: jest.fn().mockReturnValue(true),
      ...overrides
    };
  },

  /**
   * Create a mock gesture handler
   * @param {Object} overrides - Method overrides
   * @returns {Object} Mock gesture handler
   */
  createMockGestureHandler(overrides = {}) {
    return {
      initialize: jest.fn(),
      enable: jest.fn(),
      disable: jest.fn(),
      destroy: jest.fn(),
      updateGestureZoneHeight: jest.fn(),
      isListening: false,
      gestureActive: false,
      isDragging: false,
      gestureZoneHeight: 50,
      dragThreshold: 20,
      ...overrides
    };
  },

  /**
   * Simulate a touch event sequence
   * @param {Element} element - Target element
   * @param {Array} touches - Array of touch positions {x, y}
   * @param {string} eventType - Touch event type
   */
  simulateTouch(element, touches, eventType = 'touchstart') {
    const touchList = touches.map((touch, index) => ({
      identifier: index,
      target: element,
      clientX: touch.x,
      clientY: touch.y,
      pageX: touch.x,
      pageY: touch.y,
      screenX: touch.x,
      screenY: touch.y,
      radiusX: 1,
      radiusY: 1,
      rotationAngle: 0,
      force: 1
    }));

    let touchEvent;
    try {
      // Try to create a real TouchEvent
      touchEvent = new TouchEvent(eventType, {
        touches: eventType !== 'touchend' ? touchList : [],
        targetTouches: eventType !== 'touchend' ? touchList : [],
        changedTouches: touchList,
        bubbles: true,
        cancelable: true
      });
    } catch (error) {
      // Fallback to creating a mock event object
      touchEvent = new Event(eventType, {
        bubbles: true,
        cancelable: true
      });
      
      // Add touch properties manually
      Object.defineProperty(touchEvent, 'touches', {
        value: eventType !== 'touchend' ? touchList : [],
        writable: false,
        configurable: true
      });
      
      Object.defineProperty(touchEvent, 'targetTouches', {
        value: eventType !== 'touchend' ? touchList : [],
        writable: false,
        configurable: true
      });
      
      Object.defineProperty(touchEvent, 'changedTouches', {
        value: touchList,
        writable: false,
        configurable: true
      });
    }

    // Ensure preventDefault exists
    if (!touchEvent.preventDefault) {
      touchEvent.preventDefault = jest.fn();
    }

    element.dispatchEvent(touchEvent);
  },

  /**
   * Simulate drag gesture sequence
   * @param {Element} element - Target element
   * @param {Object} startPos - Start position {x, y}
   * @param {Object} endPos - End position {x, y}
   * @param {number} steps - Number of intermediate steps
   */
  async simulateDrag(element, startPos, endPos, steps = 5) {
    // Start touch
    this.simulateTouch(element, [startPos], 'touchstart');
    
    // Intermediate moves
    for (let i = 1; i <= steps; i++) {
      const progress = i / steps;
      const x = startPos.x + (endPos.x - startPos.x) * progress;
      const y = startPos.y + (endPos.y - startPos.y) * progress;
      
      this.simulateTouch(element, [{x, y}], 'touchmove');
      await this.waitForTimeout(10);
    }
    
    // End touch
    this.simulateTouch(element, [endPos], 'touchend');
  },

  /**
   * Mock media query matching
   * @param {string} query - Media query string
   * @param {boolean} matches - Whether query matches
   */
  mockMediaQuery(query, matches = false) {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: jest.fn().mockImplementation(q => ({
        matches: q === query ? matches : false,
        media: q,
        onchange: null,
        addListener: jest.fn(),
        removeListener: jest.fn(),
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn(),
      })),
    });
  },

  /**
   * Mock user agent string
   * @param {string} userAgent - User agent string
   */
  mockUserAgent(userAgent) {
    Object.defineProperty(navigator, 'userAgent', {
      writable: true,
      configurable: true,
      value: userAgent,
    });
  },

  /**
   * Setup accessibility testing helpers
   */
  setupA11yHelpers() {
    // Mock screen reader announcements
    window.mockScreenReaderAnnouncements = [];
    
    const originalSetAttribute = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, value) {
      if (name === 'aria-live' || name === 'role') {
        window.mockScreenReaderAnnouncements.push({
          element: this,
          attribute: name,
          value: value,
          timestamp: Date.now()
        });
      }
      return originalSetAttribute.call(this, name, value);
    };
  },

  /**
   * Get mock screen reader announcements
   * @returns {Array} Array of announcements
   */
  getScreenReaderAnnouncements() {
    return window.mockScreenReaderAnnouncements || [];
  },

  /**
   * Clear screen reader announcements
   */
  clearScreenReaderAnnouncements() {
    window.mockScreenReaderAnnouncements = [];
  },

  /**
   * Verify element focus order
   * @param {Array} expectedOrder - Array of element selectors in expected tab order
   * @returns {boolean} Whether focus order matches
   */
  verifyFocusOrder(expectedOrder) {
    const focusableElements = expectedOrder.map(selector => document.querySelector(selector));
    
    for (let i = 0; i < focusableElements.length; i++) {
      const element = focusableElements[i];
      if (!element) continue;
      
      element.focus();
      if (document.activeElement !== element) {
        return false;
      }
      
      // Simulate Tab key
      this.pressKey('Tab');
      
      const nextIndex = (i + 1) % focusableElements.length;
      const expectedNext = focusableElements[nextIndex];
      
      if (expectedNext && document.activeElement !== expectedNext) {
        return false;
      }
    }
    
    return true;
  },

  /**
   * Check if element has proper ARIA attributes
   * @param {Element} element - Element to check
   * @param {Object} expectedAria - Expected ARIA attributes
   * @returns {boolean} Whether element has correct ARIA
   */
  hasProperAria(element, expectedAria) {
    for (const [attr, expectedValue] of Object.entries(expectedAria)) {
      const actualValue = element.getAttribute(`aria-${attr}`);
      if (actualValue !== expectedValue) {
        console.warn(`ARIA mismatch on ${element.tagName}: expected aria-${attr}="${expectedValue}", got "${actualValue}"`);
        return false;
      }
    }
    return true;
  },

  /**
   * Mock performance timing for testing
   */
  mockPerformanceTiming() {
    const mockPerformance = {
      mark: jest.fn(),
      measure: jest.fn(),
      now: jest.fn(() => Date.now()),
      getEntriesByType: jest.fn(() => []),
      getEntriesByName: jest.fn(() => [])
    };
    
    Object.defineProperty(window, 'performance', {
      writable: true,
      configurable: true,
      value: mockPerformance
    });
    
    return mockPerformance;
  },

  /**
   * Setup viewport meta tag for mobile testing
   */
  setupMobileViewport() {
    const viewport = document.createElement('meta');
    viewport.name = 'viewport';
    viewport.content = 'width=device-width, initial-scale=1.0, user-scalable=no';
    document.head.appendChild(viewport);
  },

  /**
   * Create a promise that resolves after animation frame
   * @returns {Promise}
   */
  nextFrame() {
    return new Promise(resolve => {
      requestAnimationFrame(resolve);
    });
  },

  /**
   * Flush all pending promises and timers
   * @returns {Promise}
   */
  async flushPromises() {
    await new Promise(resolve => setImmediate(resolve));
    jest.runOnlyPendingTimers();
  },

  /**
   * Mock console methods to prevent spam during tests
   */
  mockConsole() {
    const originalConsole = { ...console };
    
    console.log = jest.fn();
    console.warn = jest.fn();
    console.error = jest.fn();
    console.info = jest.fn();
    
    return {
      restore: () => {
        Object.assign(console, originalConsole);
      },
      logs: console.log,
      warnings: console.warn,
      errors: console.error,
      info: console.info
    };
  },

  /**
   * Trigger custom events on elements
   * @param {Element} element - Target element
   * @param {string} eventType - Event type to trigger
   * @param {Object} eventOptions - Event options
   */
  triggerEvent(element, eventType, eventOptions = {}) {
    const event = new Event(eventType, {
      bubbles: true,
      cancelable: true,
      ...eventOptions
    });
    
    // Add custom properties if provided
    if (eventOptions.detail) {
      Object.defineProperty(event, 'detail', {
        value: eventOptions.detail,
        writable: false
      });
    }
    
    element.dispatchEvent(event);
    return event;
  },

  /**
   * Trigger keyboard events with proper key codes
   * @param {Element} element - Target element
   * @param {string} eventType - Event type (keydown, keyup, keypress)
   * @param {string} key - Key value
   * @param {Object} options - Additional event options
   */
  triggerKeyboardEvent(element, eventType, key, options = {}) {
    const event = new KeyboardEvent(eventType, {
      key,
      code: key,
      bubbles: true,
      cancelable: true,
      ...options
    });
    
    element.dispatchEvent(event);
    return event;
  },

  /**
   * Trigger mouse events with coordinates
   * @param {Element} element - Target element
   * @param {string} eventType - Event type (click, mousedown, mouseup, etc.)
   * @param {Object} coordinates - Mouse coordinates {x, y}
   * @param {Object} options - Additional event options
   */
  triggerMouseEvent(element, eventType, coordinates = {}, options = {}) {
    const { x = 0, y = 0 } = coordinates;
    const event = new MouseEvent(eventType, {
      clientX: x,
      clientY: y,
      screenX: x,
      screenY: y,
      bubbles: true,
      cancelable: true,
      ...options
    });
    
    element.dispatchEvent(event);
    return event;
  },

  /**
   * Trigger form submission
   * @param {Element} form - Form element
   * @param {Object} options - Event options
   */
  triggerFormSubmit(form, options = {}) {
    const event = new Event('submit', {
      bubbles: true,
      cancelable: true,
      ...options
    });
    
    form.dispatchEvent(event);
    return event;
  }
};

// Jest custom matchers for better test assertions
expect.extend({
  /**
   * Check if element is visible
   * @param {Element} element - Element to check
   * @returns {Object} Jest matcher result
   */
  toBeVisible(element) {
    const style = window.getComputedStyle(element);
    const isVisible = style.display !== 'none' &&
                     style.visibility !== 'hidden' &&
                     style.opacity !== '0';
    
    return {
      message: () => `Expected element to ${isVisible ? 'not ' : ''}be visible`,
      pass: isVisible
    };
  },

  /**
   * Check if element has accessible name
   * @param {Element} element - Element to check
   * @returns {Object} Jest matcher result
   */
  toHaveAccessibleName(element) {
    const hasName = element.getAttribute('aria-label') ||
                   element.getAttribute('aria-labelledby') ||
                   element.closest('label') ||
                   document.querySelector(`label[for="${element.id}"]`);
    
    return {
      message: () => `Expected element to ${hasName ? 'not ' : ''}have accessible name`,
      pass: !!hasName
    };
  },

  /**
   * Check if element is focusable
   * @param {Element} element - Element to check
   * @returns {Object} Jest matcher result
   */
  toBeFocusable(element) {
    const isFocusable = element.tabIndex >= 0 ||
                       ['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON', 'A'].includes(element.tagName);
    
    return {
      message: () => `Expected element to ${isFocusable ? 'not ' : ''}be focusable`,
      pass: isFocusable
    };
  }
});

// Setup global mocks that apply to all tests
beforeEach(() => {
  // Mock timers for consistent testing
  jest.useFakeTimers();
  
  // Mock requestAnimationFrame
  global.requestAnimationFrame = jest.fn(cb => setTimeout(cb, 16));
  global.cancelAnimationFrame = jest.fn(id => clearTimeout(id));
  
  // Mock AbortController for API tests
  global.AbortController = jest.fn(() => ({
    signal: { aborted: false },
    abort: jest.fn()
  }));
  
  // Mock Headers for fetch API tests
  global.Headers = jest.fn(() => new Map());
  
  // Reset window dimensions - using direct window property setting to avoid circular reference
  Object.defineProperty(window, 'innerWidth', {
    writable: true,
    configurable: true,
    value: 1200,
  });
  Object.defineProperty(window, 'innerHeight', {
    writable: true,
    configurable: true,
    value: 800,
  });
});

afterEach(() => {
  // Clean up after each test
  jest.runOnlyPendingTimers();
  jest.useRealTimers();
  
  // Clean DOM
  document.head.innerHTML = '';
  document.body.innerHTML = '';
  
  // Reset window properties
  delete window.GestureHandler;
  delete window.SettingsAPI;
  delete window.SettingsPanel;
  delete window.Layout3x4;
  delete window.Layout4x8;
  delete window.WhatsNextView;
  
  // Clear screen reader announcements if available
  if (window.mockScreenReaderAnnouncements) {
    window.mockScreenReaderAnnouncements = [];
  }
  
  // Restore original console if mocked
  if (console.log && console.log.mockRestore) {
    console.log.mockRestore();
  }
  if (console.warn && console.warn.mockRestore) {
    console.warn.mockRestore();
  }
  if (console.error && console.error.mockRestore) {
    console.error.mockRestore();
  }
  if (console.info && console.info.mockRestore) {
    console.info.mockRestore();
  }
});

export default testUtils;