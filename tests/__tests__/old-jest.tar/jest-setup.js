/**
 * @fileoverview Jest setup file to properly load browser-style modules
 * Ensures classes like GestureHandler, SettingsPanel are available on window object
 */

// CRITICAL: Suppress JSDOM navigation errors that occur during Jest initialization
// This prevents "Error: Not implemented: navigation" errors during environment setup
const originalConsoleError = console.error;
console.error = (...args) => {
  const message = args.join(' ');
  if (message.includes('Error: Not implemented: navigation') ||
      message.includes('navigateFetch') ||
      message.includes('_locationObjectNavigate')) {
    // Silently suppress JSDOM navigation errors
    return;
  }
  originalConsoleError.apply(console, args);
};

// Fix Node.js compatibility issues for JSDOM
const { TextEncoder, TextDecoder } = require('util');
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Mock browser APIs that the modules depend on
global.Headers = jest.fn(() => new Map());
global.AbortController = jest.fn(() => ({
  signal: { aborted: false },
  abort: jest.fn()
}));

// Mock additional Web APIs
global.fetch = jest.fn();
global.Request = jest.fn();
global.Response = jest.fn();

// Location will be mocked after JSDOM setup below

// Pre-define missing dependency classes as empty mock implementations
global.window.SettingsAPI = class MockSettingsAPI {
  constructor() {}
  getSettings() { return Promise.resolve({}); }
  updateSettings() { return Promise.resolve({}); }
  updateSetting() { return Promise.resolve(true); }
  createSettings() { return Promise.resolve({}); }
  deleteSettings() { return Promise.resolve({}); }
  deleteSetting() { return Promise.resolve({}); }
  validateSettings() { return true; }
  validateSetting() { return true; }
};

global.window.GestureHandler = class MockGestureHandler {
  constructor() {}
  initialize() {}
  enable() {}
  disable() {}
  destroy() {}
  updateGestureZoneHeight() {}
  isListening = false;
  gestureActive = false;
  isDragging = false;
  gestureZoneHeight = 50;
  dragThreshold = 20;
};

global.window.SettingsPanel = class MockSettingsPanel {
  constructor() {}
  initialize() { return Promise.resolve(); }
  destroy() {}
};

// Ensure classes are also available as direct globals AND on window object
global.SettingsAPI = global.window.SettingsAPI;
global.GestureHandler = global.window.GestureHandler;
global.SettingsPanel = global.window.SettingsPanel;

// CRITICAL: Also ensure they're available on the JSDOM window that tests see
global.window.SettingsAPI = global.window.SettingsAPI;
global.window.GestureHandler = global.window.GestureHandler;
global.window.SettingsPanel = global.window.SettingsPanel;

// FINAL FIX: Inject classes into the execution context where layout JavaScript runs
// This ensures they're available when layout code checks typeof SettingsAPI etc.
const injectClassesIntoWindow = () => {
  if (typeof global.window === 'object' && global.window) {
    global.window.SettingsAPI = global.SettingsAPI;
    global.window.GestureHandler = global.GestureHandler;
    global.window.SettingsPanel = global.SettingsPanel;
    
    // Also make them available as direct globals in the window context
    global.SettingsAPI = global.window.SettingsAPI;
    global.GestureHandler = global.window.GestureHandler;
    global.SettingsPanel = global.window.SettingsPanel;
  }
};

// Call immediately and also set up for each test
injectClassesIntoWindow();

// Hook into beforeEach to ensure classes are available for each test
if (typeof beforeEach !== 'undefined') {
  beforeEach(() => {
    injectClassesIntoWindow();
  });
}

// Force them into the global scope that layout code will check
Object.defineProperty(global, 'SettingsAPI', {
  value: global.window.SettingsAPI,
  writable: true,
  enumerable: true,
  configurable: true
});

Object.defineProperty(global, 'GestureHandler', {
  value: global.window.GestureHandler,
  writable: true,
  enumerable: true,
  configurable: true
});

Object.defineProperty(global, 'SettingsPanel', {
  value: global.window.SettingsPanel,
  writable: true,
  enumerable: true,
  configurable: true
});

// Add mock auto-refresh function that tests expect
global.window.isAutoRefreshEnabled = function() {
  return global.window.autoRefreshEnabled !== false;
};
global.isAutoRefreshEnabled = global.window.isAutoRefreshEnabled;

// Ensure we have proper DOM and window setup
const { JSDOM } = require('jsdom');

// Set up JSDOM with proper window globals and required DOM structure
const dom = new JSDOM(`<!DOCTYPE html>
<html>
<head></head>
<body>
  <div class="calendar-content">
    <div class="calendar-grid"></div>
    <div class="meeting-display"></div>
    <div class="time-display"></div>
    <div class="weather-widget"></div>
  </div>
  <div class="settings-panel"></div>
</body>
</html>`, {
  url: 'http://localhost:8080',
  pretendToBeVisual: true,
  resources: 'usable'
});

// Create a completely new location object with mocked reload to prevent navigation errors
const mockLocation = {
  href: 'http://localhost:8080/',
  origin: 'http://localhost:8080',
  protocol: 'http:',
  host: 'localhost:8080',
  hostname: 'localhost',
  port: '8080',
  pathname: '/',
  search: '',
  hash: '',
  reload: jest.fn(() => {
    // Silently mock location.reload() to prevent JSDOM navigation errors
    return Promise.resolve();
  }),
  assign: jest.fn((url) => {
    console.log(`location.assign(${url}) mocked`);
  }),
  replace: jest.fn((url) => {
    console.log(`location.replace(${url}) mocked`);
  }),
  toString: function() { return this.href; }
};

global.window = dom.window;
global.document = dom.window.document;
global.navigator = dom.window.navigator;

// Replace both global and window location with our mock
global.location = mockLocation;
global.window.location = mockLocation;

// Replace the JSDOM window's location completely with our mock
// This avoids the "Cannot redefine property" error
global.window = dom.window;
global.window.location = mockLocation;
global.document = dom.window.document;
global.navigator = dom.window.navigator;

// Ensure requestAnimationFrame and related APIs are available
global.requestAnimationFrame = jest.fn(cb => setTimeout(cb, 16));
global.cancelAnimationFrame = jest.fn(id => clearTimeout(id));

// Mock performance API
global.performance = {
  mark: jest.fn(),
  measure: jest.fn(),
  now: jest.fn(() => Date.now()),
  getEntriesByType: jest.fn(() => []),
  getEntriesByName: jest.fn(() => [])
};

// Mock DOMParser - Critical for parsing HTML/XML content
global.DOMParser = global.DOMParser || class MockDOMParser {
  parseFromString(htmlString, mimeType) {
    // Create a temporary div to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = htmlString;
    
    // Return a mock document-like object
    return {
      documentElement: tempDiv,
      querySelector: (selector) => tempDiv.querySelector(selector),
      querySelectorAll: (selector) => tempDiv.querySelectorAll(selector),
      getElementsByTagName: (tagName) => tempDiv.getElementsByTagName(tagName),
      getElementById: (id) => tempDiv.querySelector(`#${id}`),
      createElement: (tagName) => document.createElement(tagName),
      body: tempDiv.querySelector('body') || tempDiv,
      head: tempDiv.querySelector('head') || document.createElement('head')
    };
  }
};

// Mock XMLHttpRequest for AJAX calls
global.XMLHttpRequest = global.XMLHttpRequest || class MockXMLHttpRequest {
  constructor() {
    this.readyState = 0;
    this.status = 200;
    this.statusText = 'OK';
    this.responseText = '';
    this.response = '';
    this.onreadystatechange = null;
    this.onerror = null;
    this.onload = null;
  }
  
  open(method, url, async = true) {
    this.method = method;
    this.url = url;
    this.async = async;
    this.readyState = 1;
  }
  
  send(data) {
    this.readyState = 4;
    this.status = 200;
    this.responseText = '{"success": true}';
    this.response = this.responseText;
    
    setTimeout(() => {
      if (this.onreadystatechange) this.onreadystatechange();
      if (this.onload) this.onload();
    }, 0);
  }
  
  setRequestHeader(name, value) {
    // Mock implementation
  }
  
  getResponseHeader(name) {
    return 'application/json';
  }
};

// Add DOMParser to window object as well
global.window.DOMParser = global.DOMParser;

// Fix TouchEvent constructor for JSDOM compatibility
global.TouchEvent = global.TouchEvent || class MockTouchEvent extends Event {
  constructor(type, eventInitDict = {}) {
    super(type, eventInitDict);
    console.log(`DIAGNOSTIC: Creating TouchEvent type="${type}", options:`, eventInitDict);
    
    // Ensure changedTouches, touches, and targetTouches exist with proper structure
    const createTouch = (touch = {}) => ({
      identifier: touch.identifier || 0,
      target: touch.target || null,
      clientX: touch.clientX || 100,
      clientY: touch.clientY || 100,
      pageX: touch.pageX || touch.clientX || 100,
      pageY: touch.pageY || touch.clientY || 100,
      screenX: touch.screenX || touch.clientX || 100,
      screenY: touch.screenY || touch.clientY || 100,
      radiusX: touch.radiusX || 1,
      radiusY: touch.radiusY || 1,
      rotationAngle: touch.rotationAngle || 0,
      force: touch.force || 1
    });

    // Process touches from eventInitDict
    const touches = (eventInitDict.touches || []).map(createTouch);
    const targetTouches = (eventInitDict.targetTouches || []).map(createTouch);
    const changedTouches = (eventInitDict.changedTouches || []).map(createTouch);

    // CRITICAL: Always ensure at least one touch exists for any touch event
    if (changedTouches.length === 0) {
      const defaultTouch = createTouch({
        screenX: 100,
        screenY: 100,
        clientX: 100,
        clientY: 100
      });
      changedTouches.push(defaultTouch);
      console.log(`DIAGNOSTIC: Added default touch to changedTouches:`, defaultTouch);
    }

    // Define properties
    Object.defineProperties(this, {
      touches: { value: touches, enumerable: true },
      targetTouches: { value: targetTouches, enumerable: true },
      changedTouches: { value: changedTouches, enumerable: true }
    });
    
    console.log(`DIAGNOSTIC: TouchEvent created - changedTouches.length=${this.changedTouches.length}, changedTouches[0]:`, this.changedTouches[0]);
  }
};

// Ensure TouchEvent is available on window as well
global.window.TouchEvent = global.TouchEvent;

// Cache for loaded modules to prevent re-execution
const moduleCache = new Set();

// Function to load browser-style modules and ensure they're properly exposed
function loadBrowserModule(modulePath) {
  // Skip if already loaded
  if (moduleCache.has(modulePath)) {
    console.log(`DIAGNOSTIC: Module ${modulePath} already loaded, skipping`);
    return;
  }
  
  try {
    const fs = require('fs');
    const vm = require('vm');
    const path = require('path');
    
    // Read the module file
    const fullPath = path.resolve(modulePath);
    let moduleCode = fs.readFileSync(fullPath, 'utf8');
    
    // Remove ALL navigation-related code that can cause JSDOM errors
    moduleCode = moduleCode.replace(/window\.location\.reload\(\)/g, '/* location.reload() removed for tests */');
    moduleCode = moduleCode.replace(/location\.reload\(\)/g, '/* location.reload() removed for tests */');
    moduleCode = moduleCode.replace(/window\.location\.href\s*=\s*[^;]+/g, '/* location.href assignment removed for tests */');
    moduleCode = moduleCode.replace(/window\.location\s*=\s*[^;]+/g, '/* location assignment removed for tests */');
    moduleCode = moduleCode.replace(/location\.href\s*=\s*[^;]+/g, '/* location.href assignment removed for tests */');
    
    // CRITICAL FIX: Wrap class declarations to prevent re-declaration errors
    const classNames = ['SettingsAPI', 'GestureHandler', 'SettingsPanel'];
    classNames.forEach(className => {
      // Only modify class declarations if they exist
      const classRegex = new RegExp(`(class\\s+${className}\\b[^{]*\\{)`, 'g');
      if (moduleCode.match(classRegex)) {
        console.log(`DIAGNOSTIC: Wrapping class ${className} declaration conditionally`);
        
        // Find the entire class definition and wrap it
        const lines = moduleCode.split('\n');
        let inClass = false;
        let braceCount = 0;
        let classStartLine = -1;
        let classEndLine = -1;
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          
          // Detect class declaration start
          if (line.match(new RegExp(`class\\s+${className}\\b`)) && !inClass) {
            classStartLine = i;
            inClass = true;
            braceCount = 0;
          }
          
          if (inClass) {
            // Count braces to find class end
            const openBraces = (line.match(/\{/g) || []).length;
            const closeBraces = (line.match(/\}/g) || []).length;
            braceCount += openBraces - closeBraces;
            
            // Class ends when brace count returns to 0
            if (braceCount === 0 && i > classStartLine) {
              classEndLine = i;
              break;
            }
          }
        }
        
        // Wrap the class declaration if we found both start and end
        if (classStartLine !== -1 && classEndLine !== -1) {
          lines[classStartLine] = `if (typeof ${className} === 'undefined') {\n${lines[classStartLine]}`;
          lines[classEndLine] = `${lines[classEndLine]}\n}`;
          moduleCode = lines.join('\n');
          console.log(`DIAGNOSTIC: Successfully wrapped ${className} class declaration`);
        }
      }
    });
    
    // Create a context with window, document, and other browser globals
    const sandbox = {
      // Core browser objects
      window: {
        ...global.window,
        location: mockLocation,
        // Ensure dependencies are available in window context
        SettingsAPI: global.window.SettingsAPI,
        GestureHandler: global.window.GestureHandler,
        SettingsPanel: global.window.SettingsPanel
      },
      document: global.document,
      console: global.console,
      setTimeout: global.setTimeout,
      clearTimeout: global.clearTimeout,
      setInterval: global.setInterval,
      clearInterval: global.clearInterval,
      
      // Browser APIs
      fetch: global.fetch,
      Headers: global.Headers,
      AbortController: global.AbortController,
      TextEncoder: global.TextEncoder,
      TextDecoder: global.TextDecoder,
      DOMParser: global.DOMParser,
      XMLHttpRequest: global.XMLHttpRequest,
      TouchEvent: global.TouchEvent,
      
      // Use the globally mocked location object
      location: mockLocation,
      
      // Performance and animation APIs
      requestAnimationFrame: global.requestAnimationFrame,
      cancelAnimationFrame: global.cancelAnimationFrame,
      performance: global.performance,
      
      // Pre-define expected globals to prevent undefined errors - make them directly available
      GestureHandler: global.window.GestureHandler,
      SettingsAPI: global.window.SettingsAPI,
      SettingsPanel: global.window.SettingsPanel
    };
    
    // DIAGNOSTIC: Log VM context setup before execution
    console.log(`DIAGNOSTIC: Loading module ${modulePath}`);
    console.log(`DIAGNOSTIC: Global SettingsAPI available:`, typeof global.SettingsAPI !== 'undefined');
    console.log(`DIAGNOSTIC: Global window.SettingsAPI available:`, typeof global.window.SettingsAPI !== 'undefined');
    console.log(`DIAGNOSTIC: Sandbox SettingsAPI available:`, typeof sandbox.SettingsAPI !== 'undefined');
    console.log(`DIAGNOSTIC: Sandbox window.SettingsAPI available:`, typeof sandbox.window.SettingsAPI !== 'undefined');
    
    // Execute the module code in the sandbox with proper context
    vm.createContext(sandbox);
    
    // FINAL FIX: Inject dependencies directly before layout code execution
    const dependencyInjectionCode = `
      // Directly define the dependencies in the same execution context as layout code
      var SettingsAPI = this.SettingsAPI;
      var GestureHandler = this.GestureHandler;
      var SettingsPanel = this.SettingsPanel;
      var TouchEvent = this.TouchEvent;
      
      // Ensure they're globally available in this context
      this.SettingsAPI = SettingsAPI;
      this.GestureHandler = GestureHandler;
      this.SettingsPanel = SettingsPanel;
      this.TouchEvent = TouchEvent;
      
      // Make available on window object if it exists
      if (typeof window !== 'undefined') {
        window.SettingsAPI = SettingsAPI;
        window.GestureHandler = GestureHandler;
        window.SettingsPanel = SettingsPanel;
        window.TouchEvent = TouchEvent;
      }
      
      // CRITICAL: Inject proper TouchEvent mock into VM context
      var TouchEvent = this.TouchEvent || (function(type, options) {
        var event = new Event(type);
        var opts = options || {};
        var defaultTouch = {
          screenX: 100, screenY: 100, clientX: 100, clientY: 100,
          pageX: 100, pageY: 100, radiusX: 10, radiusY: 10,
          rotationAngle: 0, force: 1, identifier: 0, target: null
        };
        event.touches = opts.touches || [defaultTouch];
        event.targetTouches = opts.targetTouches || [defaultTouch];
        event.changedTouches = opts.changedTouches || [defaultTouch];
        return event;
      });
    `;
    
    // Execute dependency injection first, then the module code
    vm.runInContext(dependencyInjectionCode, sandbox);
    vm.runInContext(moduleCode, sandbox);
    
    // Extract any new objects and expose them globally
    ['GestureHandler', 'SettingsAPI', 'SettingsPanel', 'Layout3x4', 'Layout4x8', 'WhatsNextView'].forEach(className => {
      // Check multiple possible locations for the class
      let classFound = false;
      
      if (sandbox[className] && typeof sandbox[className] !== 'undefined') {
        global.window[className] = sandbox[className];
        global[className] = sandbox[className];
        classFound = true;
      } else if (sandbox.window && sandbox.window[className]) {
        global.window[className] = sandbox.window[className];
        global[className] = sandbox.window[className];
        classFound = true;
      }
      
      // Force the classes to be available during module execution context
      if (classFound) {
        // Also ensure they're available in the current execution context
        Object.defineProperty(global, className, {
          value: global.window[className],
          writable: true,
          enumerable: true,
          configurable: true
        });
        
        // Make sure they're in the sandbox context too for subsequent module loads
        sandbox[className] = global.window[className];
        if (sandbox.window) {
          sandbox.window[className] = global.window[className];
        }
      }
    });
    
    // Mark as loaded
    moduleCache.add(modulePath);
    console.log(`DIAGNOSTIC: Module ${modulePath} loaded successfully and cached`);
    
  } catch (error) {
    console.error(`Jest setup: Failed to load module ${modulePath}:`, error.message);
  }
}

// Pre-load all the browser modules that tests need with correct paths
try {
  // Load in dependency order - using correct paths from project root
  loadBrowserModule('calendarbot/web/static/shared/js/settings-api.js');
  loadBrowserModule('calendarbot/web/static/shared/js/gesture-handler.js');
  loadBrowserModule('calendarbot/web/static/shared/js/settings-panel.js');
  
  // Load layout modules
  loadBrowserModule('calendarbot/web/static/layouts/3x4/3x4.js');
  loadBrowserModule('calendarbot/web/static/layouts/4x8/4x8.js');
  loadBrowserModule('calendarbot/web/static/layouts/whats-next-view/whats-next-view.js');
  
} catch (error) {
  console.error('Jest setup: Failed to load browser modules:', error);
}

// CRITICAL FIX: Final dependency injection - direct JSDOM global assignment
// This ensures dependencies are available in the exact context where layout code executes during tests

// After JSDOM setup, inject dependencies directly into the test execution environment
console.log('FINAL INJECTION: Setting up dependencies in JSDOM global context...');

// Ensure dependencies are available in the global JSDOM context where tests execute
// This is the context where `typeof SettingsAPI` is checked in layout code
globalThis.SettingsAPI = global.window.SettingsAPI;
globalThis.GestureHandler = global.window.GestureHandler;
globalThis.SettingsPanel = global.window.SettingsPanel;

// Also ensure they're available as direct globals in the window context
global.window.SettingsAPI = global.SettingsAPI;
global.window.GestureHandler = global.GestureHandler;
global.window.SettingsPanel = global.SettingsPanel;

// Ensure auto-refresh is available
globalThis.isAutoRefreshEnabled = global.isAutoRefreshEnabled;
global.window.isAutoRefreshEnabled = global.isAutoRefreshEnabled;

// Fix auto-refresh default value
global.window.autoRefreshEnabled = true;

console.log('FINAL INJECTION VERIFICATION:');
console.log('  - globalThis.SettingsAPI:', typeof globalThis.SettingsAPI);
console.log('  - global.window.SettingsAPI:', typeof global.window.SettingsAPI);
console.log('  - global.SettingsAPI:', typeof global.SettingsAPI);

// Expose the loadBrowserModule function globally for tests that need to reload modules
global.loadBrowserModule = loadBrowserModule;