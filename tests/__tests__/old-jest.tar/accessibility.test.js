/**
 * @fileoverview Comprehensive test suite for accessibility features
 * Tests keyboard navigation, ARIA compliance, screen reader support, and WCAG guidelines
 */

describe('Accessibility - Keyboard Navigation and ARIA', () => {
  let settingsPanel;
  let gestureHandler;
  let mockSettingsAPI;
  let consoleLogSpy;

  beforeEach(() => {
    // Reset DOM
    testUtils.cleanupDOM();
    testUtils.setupMockDOM(`
      <html lang="en">
        <head>
          <title>CalendarBot Settings</title>
          <style>
            .settings-panel { position: fixed; top: 0; right: -400px; width: 400px; height: 100%; }
            .settings-panel.open { right: 0; }
            .settings-panel:focus-within { outline: 2px solid #007bff; }
            .form-group { margin-bottom: 20px; }
            .form-group label { display: block; margin-bottom: 5px; }
            .form-group input:focus, .form-group select:focus { outline: 2px solid #007bff; }
            .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0; }
            .focus-trap { position: relative; }
            .high-contrast { filter: contrast(150%); }
            @media (prefers-reduced-motion: reduce) {
              .settings-panel { transition: none; }
            }
          </style>
        </head>
        <body>
          <div class="settings-panel focus-trap" id="settings-panel" role="dialog" aria-labelledby="settings-title" aria-describedby="settings-description" aria-modal="true">
            <div class="settings-header">
              <h2 id="settings-title">Settings</h2>
              <p id="settings-description" class="sr-only">Configure your CalendarBot preferences</p>
              <button class="settings-close" id="settings-close" aria-label="Close settings panel">×</button>
            </div>
            <div class="settings-content">
              <form id="settings-form" class="settings-form" role="form" aria-labelledby="settings-title">
                <div class="form-group">
                  <label for="theme" id="theme-label">Theme</label>
                  <select id="theme" name="theme" aria-labelledby="theme-label" aria-describedby="theme-help">
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                    <option value="auto">Auto</option>
                  </select>
                  <div id="theme-help" class="sr-only">Choose the visual theme for the interface</div>
                </div>
                
                <div class="form-group">
                  <label for="auto-save" id="auto-save-label">
                    <input type="checkbox" id="auto-save" name="autoSave" aria-labelledby="auto-save-label" aria-describedby="auto-save-help">
                    Auto-save settings
                  </label>
                  <div id="auto-save-help" class="sr-only">Automatically save changes as you make them</div>
                </div>
                
                <div class="form-group">
                  <label for="refresh-interval" id="refresh-label">Refresh Interval (minutes)</label>
                  <input type="number" id="refresh-interval" name="refreshInterval" min="1" max="60" aria-labelledby="refresh-label" aria-describedby="refresh-help">
                  <div id="refresh-help" class="sr-only">How often to refresh calendar data, between 1 and 60 minutes</div>
                </div>
                
                <fieldset class="form-group">
                  <legend id="filters-legend">Event Filters</legend>
                  <div class="filter-list" id="filter-list" role="list" aria-labelledby="filters-legend">
                    <!-- Dynamic filter items will be added here -->
                  </div>
                  <div class="add-filter">
                    <label for="new-filter" class="sr-only">Add new event filter</label>
                    <input type="text" id="new-filter" placeholder="Add new filter" aria-describedby="filter-help">
                    <button type="button" id="add-filter-btn" aria-describedby="filter-help">Add Filter</button>
                    <div id="filter-help" class="sr-only">Enter a filter name and press Add Filter or Enter to create it</div>
                  </div>
                </fieldset>
                
                <div class="form-actions" role="group" aria-label="Form actions">
                  <button type="submit" id="save-settings">Save Changes</button>
                  <button type="button" id="reset-settings">Reset to Defaults</button>
                </div>
              </form>
              
              <div class="settings-status" id="settings-status" role="status" aria-live="polite" aria-atomic="true"></div>
            </div>
          </div>
          
          <!-- Live region for announcements -->
          <div id="aria-live-region" aria-live="assertive" aria-atomic="true" class="sr-only"></div>
        </body>
      </html>
    `);

    // Setup console spy
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    // Mock dependencies
    mockSettingsAPI = {
      getSettings: jest.fn(),
      updateSettings: jest.fn(),
      updateSetting: jest.fn(),
      validateSettings: jest.fn(),
      validateSetting: jest.fn()
    };

    // Load modules
    require('../../calendarbot/web/static/shared/js/settings-api.js');
    require('../../calendarbot/web/static/shared/js/gesture-handler.js');
    require('../../calendarbot/web/static/shared/js/settings-panel.js');
  });

  afterEach(() => {
    if (settingsPanel) {
      settingsPanel.destroy();
    }
    if (gestureHandler) {
      gestureHandler.destroy();
    }
    jest.clearAllMocks();
    testUtils.cleanupDOM();
  });

  describe('ARIA Attributes and Semantic Structure', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        eventFilter: ['work', 'personal']
      });
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should have correct dialog role and attributes', () => {
      const panelElement = document.getElementById('settings-panel');
      
      expect(panelElement.getAttribute('role')).toBe('dialog');
      expect(panelElement.getAttribute('aria-modal')).toBe('true');
      expect(panelElement.getAttribute('aria-labelledby')).toBe('settings-title');
      expect(panelElement.getAttribute('aria-describedby')).toBe('settings-description');
    });

    it('should have proper form labeling', () => {
      const form = document.getElementById('settings-form');
      const themeSelect = document.getElementById('theme');
      const autoSaveCheckbox = document.getElementById('auto-save');
      const refreshInput = document.getElementById('refresh-interval');
      
      expect(form.getAttribute('role')).toBe('form');
      expect(form.getAttribute('aria-labelledby')).toBe('settings-title');
      
      expect(themeSelect.getAttribute('aria-labelledby')).toBe('theme-label');
      expect(themeSelect.getAttribute('aria-describedby')).toBe('theme-help');
      
      expect(autoSaveCheckbox.getAttribute('aria-labelledby')).toBe('auto-save-label');
      expect(autoSaveCheckbox.getAttribute('aria-describedby')).toBe('auto-save-help');
      
      expect(refreshInput.getAttribute('aria-labelledby')).toBe('refresh-label');
      expect(refreshInput.getAttribute('aria-describedby')).toBe('refresh-help');
    });

    it('should have proper fieldset and legend for grouped elements', () => {
      const filtersFieldset = document.querySelector('fieldset');
      const filtersLegend = document.getElementById('filters-legend');
      const filterList = document.getElementById('filter-list');
      
      expect(filtersFieldset).toBeTruthy();
      expect(filtersLegend.tagName).toBe('LEGEND');
      expect(filterList.getAttribute('role')).toBe('list');
      expect(filterList.getAttribute('aria-labelledby')).toBe('filters-legend');
    });

    it('should have live regions for dynamic content', () => {
      const statusElement = document.getElementById('settings-status');
      const liveRegion = document.getElementById('aria-live-region');
      
      expect(statusElement.getAttribute('role')).toBe('status');
      expect(statusElement.getAttribute('aria-live')).toBe('polite');
      expect(statusElement.getAttribute('aria-atomic')).toBe('true');
      
      expect(liveRegion.getAttribute('aria-live')).toBe('assertive');
      expect(liveRegion.getAttribute('aria-atomic')).toBe('true');
    });

    it('should have screen reader only content for context', () => {
      const srOnlyElements = document.querySelectorAll('.sr-only');
      
      expect(srOnlyElements.length).toBeGreaterThan(0);
      
      srOnlyElements.forEach(element => {
        const style = window.getComputedStyle(element);
        expect(style.position).toBe('absolute');
        expect(style.width).toBe('1px');
        expect(style.height).toBe('1px');
      });
    });

    it('should add proper ARIA attributes to dynamic filter items', async () => {
      // Trigger filter rendering
      await settingsPanel.renderEventFilters(['work', 'personal', 'family']);
      
      const filterList = document.getElementById('filter-list');
      const filterItems = filterList.querySelectorAll('.filter-item');
      
      filterItems.forEach((item, index) => {
        expect(item.getAttribute('role')).toBe('listitem');
        expect(item.getAttribute('aria-label')).toContain('filter');
        
        const deleteButton = item.querySelector('.filter-delete');
        if (deleteButton) {
          expect(deleteButton.getAttribute('aria-label')).toContain('Remove');
        }
      });
    });
  });

  describe('Keyboard Navigation', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
    });

    it('should support Tab navigation through form elements', () => {
      const themeSelect = document.getElementById('theme');
      const autoSaveCheckbox = document.getElementById('auto-save');
      const refreshInput = document.getElementById('refresh-interval');
      const newFilterInput = document.getElementById('new-filter');
      const addFilterBtn = document.getElementById('add-filter-btn');
      const saveBtn = document.getElementById('save-settings');
      const resetBtn = document.getElementById('reset-settings');
      const closeBtn = document.getElementById('settings-close');
      
      // Focus should move through elements in logical order
      themeSelect.focus();
      expect(document.activeElement).toBe(themeSelect);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(autoSaveCheckbox);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(refreshInput);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(newFilterInput);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(addFilterBtn);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(saveBtn);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(resetBtn);
      
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(closeBtn);
    });

    it('should support Shift+Tab for reverse navigation', () => {
      const closeBtn = document.getElementById('settings-close');
      const resetBtn = document.getElementById('reset-settings');
      
      closeBtn.focus();
      expect(document.activeElement).toBe(closeBtn);
      
      testUtils.pressKey('Tab', { shiftKey: true });
      expect(document.activeElement).toBe(resetBtn);
    });

    it('should close panel on Escape key', () => {
      expect(settingsPanel.isOpen).toBe(true);
      
      testUtils.pressKey('Escape');
      
      expect(settingsPanel.isOpen).toBe(false);
    });

    it('should activate buttons on Enter and Space', () => {
      const saveBtn = document.getElementById('save-settings');
      const clickSpy = jest.spyOn(saveBtn, 'click');
      
      saveBtn.focus();
      
      testUtils.pressKey('Enter');
      expect(clickSpy).toHaveBeenCalled();
      
      clickSpy.mockClear();
      
      testUtils.pressKey(' '); // Space key
      expect(clickSpy).toHaveBeenCalled();
      
      clickSpy.mockRestore();
    });

    it('should support Enter key to add filters', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'family']);
      
      const newFilterInput = document.getElementById('new-filter');
      newFilterInput.value = 'family';
      newFilterInput.focus();
      
      testUtils.pressKey('Enter');
      
      await testUtils.waitForTimeout(100);
      
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('eventFilter', ['family']);
    });

    it('should support arrow key navigation in select elements', () => {
      const themeSelect = document.getElementById('theme');
      themeSelect.focus();
      
      // Initial value
      expect(themeSelect.value).toBe('dark');
      
      testUtils.pressKey('ArrowDown');
      expect(themeSelect.value).toBe('light');
      
      testUtils.pressKey('ArrowDown');
      expect(themeSelect.value).toBe('auto');
      
      testUtils.pressKey('ArrowUp');
      expect(themeSelect.value).toBe('light');
    });

    it('should support space key to toggle checkboxes', () => {
      const autoSaveCheckbox = document.getElementById('auto-save');
      autoSaveCheckbox.focus();
      
      const initialChecked = autoSaveCheckbox.checked;
      
      testUtils.pressKey(' '); // Space key
      
      expect(autoSaveCheckbox.checked).toBe(!initialChecked);
    });
  });

  describe('Focus Management', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should trap focus within the panel when open', () => {
      settingsPanel.open();
      
      const closeBtn = document.getElementById('settings-close');
      const themeSelect = document.getElementById('theme');
      
      // Focus should move to first focusable element
      expect(document.activeElement).toBe(themeSelect);
      
      // Tab from last element should wrap to first
      closeBtn.focus();
      testUtils.pressKey('Tab');
      expect(document.activeElement).toBe(themeSelect);
      
      // Shift+Tab from first element should wrap to last
      themeSelect.focus();
      testUtils.pressKey('Tab', { shiftKey: true });
      expect(document.activeElement).toBe(closeBtn);
    });

    it('should restore focus when panel closes', () => {
      const triggerElement = document.createElement('button');
      triggerElement.id = 'trigger-btn';
      document.body.appendChild(triggerElement);
      triggerElement.focus();
      
      settingsPanel.open();
      expect(document.activeElement).not.toBe(triggerElement);
      
      settingsPanel.close();
      expect(document.activeElement).toBe(triggerElement);
      
      document.body.removeChild(triggerElement);
    });

    it('should maintain focus on validation errors', async () => {
      settingsPanel.open();
      
      const refreshInput = document.getElementById('refresh-interval');
      refreshInput.focus();
      refreshInput.value = '120'; // Invalid value
      
      const changeEvent = new Event('change');
      refreshInput.dispatchEvent(changeEvent);
      
      await testUtils.waitForUpdates();
      
      // Focus should remain on the invalid field
      expect(document.activeElement).toBe(refreshInput);
      
      // Should have aria-invalid attribute
      expect(refreshInput.getAttribute('aria-invalid')).toBe('true');
    });

    it('should announce focus changes to screen readers', () => {
      settingsPanel.open();
      
      const liveRegion = document.getElementById('aria-live-region');
      const themeSelect = document.getElementById('theme');
      
      themeSelect.focus();
      
      // Should announce the current selection
      expect(liveRegion.textContent).toContain('Theme field focused');
    });

    it('should handle focus for dynamically added elements', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        eventFilter: ['work']
      });
      
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const newFilterInput = document.getElementById('new-filter');
      newFilterInput.value = 'personal';
      newFilterInput.focus();
      
      testUtils.pressKey('Enter');
      
      await testUtils.waitForUpdates();
      
      // Focus should return to input for adding another filter
      expect(document.activeElement).toBe(newFilterInput);
      expect(newFilterInput.value).toBe(''); // Should be cleared
    });
  });

  describe('Screen Reader Support', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        eventFilter: ['work', 'personal']
      });
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should announce panel opening', () => {
      const liveRegion = document.getElementById('aria-live-region');
      
      settingsPanel.open();
      
      expect(liveRegion.textContent).toContain('Settings panel opened');
    });

    it('should announce setting changes', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue('light');
      
      settingsPanel.open();
      
      const themeSelect = document.getElementById('theme');
      const liveRegion = document.getElementById('aria-live-region');
      
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(100);
      
      expect(liveRegion.textContent).toContain('Theme changed to light');
    });

    it('should announce save status', async () => {
      mockSettingsAPI.updateSettings.mockResolvedValue({});
      
      settingsPanel.open();
      
      const saveBtn = document.getElementById('save-settings');
      const statusElement = document.getElementById('settings-status');
      
      saveBtn.click();
      
      await testUtils.waitForUpdates();
      
      expect(statusElement.textContent).toContain('Settings saved successfully');
    });

    it('should announce validation errors', async () => {
      settingsPanel.open();
      
      const refreshInput = document.getElementById('refresh-interval');
      const liveRegion = document.getElementById('aria-live-region');
      
      refreshInput.value = '0'; // Invalid value
      refreshInput.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      expect(liveRegion.textContent).toContain('Error: Refresh interval must be between 1 and 60');
      expect(refreshInput.getAttribute('aria-invalid')).toBe('true');
      expect(refreshInput.getAttribute('aria-describedby')).toContain('error');
    });

    it('should provide context for filter operations', async () => {
      settingsPanel.open();
      
      const filterList = document.getElementById('filter-list');
      const filters = filterList.querySelectorAll('.filter-item');
      
      expect(filters.length).toBe(2);
      
      filters.forEach((filter, index) => {
        const deleteBtn = filter.querySelector('.filter-delete');
        expect(deleteBtn.getAttribute('aria-label')).toContain(`Remove ${['work', 'personal'][index]} filter`);
      });
    });

    it('should announce filter addition and removal', async () => {
      mockSettingsAPI.updateSetting.mockResolvedValue(['work', 'personal', 'family']);
      
      settingsPanel.open();
      
      const newFilterInput = document.getElementById('new-filter');
      const liveRegion = document.getElementById('aria-live-region');
      
      newFilterInput.value = 'family';
      newFilterInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
      
      await testUtils.waitForTimeout(100);
      
      expect(liveRegion.textContent).toContain('Filter "family" added');
    });

    it('should provide form completion status', async () => {
      settingsPanel.open();
      
      const form = document.getElementById('settings-form');
      const statusElement = document.getElementById('settings-status');
      
      // Simulate form validation
      const requiredFields = form.querySelectorAll('[required]');
      const completedFields = Array.from(requiredFields).filter(field => field.value);
      
      if (requiredFields.length > 0) {
        const completionPercentage = Math.round((completedFields.length / requiredFields.length) * 100);
        expect(statusElement.getAttribute('aria-label')).toContain(`Form ${completionPercentage}% complete`);
      }
    });
  });

  describe('High Contrast and Visual Accessibility', () => {
    beforeEach(async () => {
      // Mock prefers-contrast media query
      Object.defineProperty(window, 'matchMedia', {
        writable: true,
        value: jest.fn().mockImplementation(query => ({
          matches: query === '(prefers-contrast: high)',
          media: query,
          onchange: null,
          addListener: jest.fn(),
          removeListener: jest.fn(),
          addEventListener: jest.fn(),
          removeEventListener: jest.fn(),
          dispatchEvent: jest.fn(),
        })),
      });
      
      mockSettingsAPI.getSettings.mockResolvedValue({});
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should apply high contrast mode when preferred', () => {
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('high-contrast')).toBe(true);
    });

    it('should have sufficient color contrast for focus indicators', () => {
      const focusableElements = document.querySelectorAll('input, select, button');
      
      focusableElements.forEach(element => {
        element.focus();
        const style = window.getComputedStyle(element);
        
        // Focus outline should be visible
        expect(style.outline).toBeTruthy();
        expect(style.outlineWidth).not.toBe('0px');
      });
    });

    it('should respect reduced motion preferences', () => {
      // Mock prefers-reduced-motion
      window.matchMedia = jest.fn().mockImplementation(query => ({
        matches: query === '(prefers-reduced-motion: reduce)',
        media: query,
        onchange: null,
        addListener: jest.fn(),
        removeListener: jest.fn(),
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn(),
      }));
      
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const style = window.getComputedStyle(panelElement);
      
      expect(style.transition).toBe('none');
    });

    it('should provide alternative text for visual elements', () => {
      const closeButton = document.getElementById('settings-close');
      
      expect(closeButton.getAttribute('aria-label')).toBe('Close settings panel');
      expect(closeButton.textContent).toBe('×'); // Visual indicator
    });
  });

  describe('Error Handling and Recovery', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should provide clear error messages with context', async () => {
      settingsPanel.open();
      
      const refreshInput = document.getElementById('refresh-interval');
      refreshInput.value = '120';
      refreshInput.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      const errorElement = document.querySelector(`#${refreshInput.getAttribute('aria-describedby')}`);
      expect(errorElement).toBeTruthy();
      expect(errorElement.textContent).toContain('must be between 1 and 60');
      expect(errorElement.getAttribute('role')).toBe('alert');
    });

    it('should guide users to fix validation errors', async () => {
      settingsPanel.open();
      
      const form = document.getElementById('settings-form');
      const refreshInput = document.getElementById('refresh-interval');
      const liveRegion = document.getElementById('aria-live-region');
      
      // Set invalid value
      refreshInput.value = '0';
      
      // Try to submit form
      form.dispatchEvent(new Event('submit'));
      
      await testUtils.waitForUpdates();
      
      expect(liveRegion.textContent).toContain('Please fix the following errors');
      expect(document.activeElement).toBe(refreshInput); // Focus on first error
    });

    it('should clear errors when fields become valid', async () => {
      settingsPanel.open();
      
      const refreshInput = document.getElementById('refresh-interval');
      
      // Set invalid value
      refreshInput.value = '0';
      refreshInput.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      expect(refreshInput.getAttribute('aria-invalid')).toBe('true');
      
      // Fix the value
      refreshInput.value = '30';
      refreshInput.dispatchEvent(new Event('change'));
      
      await testUtils.waitForUpdates();
      
      expect(refreshInput.getAttribute('aria-invalid')).toBe('false');
      
      const errorElement = document.querySelector('.field-error');
      expect(errorElement).toBeFalsy();
    });

    it('should handle network errors gracefully', async () => {
      mockSettingsAPI.updateSetting.mockRejectedValue(new Error('Network error'));
      
      settingsPanel.open();
      
      const themeSelect = document.getElementById('theme');
      const liveRegion = document.getElementById('aria-live-region');
      
      themeSelect.value = 'light';
      themeSelect.dispatchEvent(new Event('change'));
      
      await testUtils.waitForTimeout(1100); // Wait for auto-save
      
      expect(liveRegion.textContent).toContain('Error saving settings. Please try again.');
    });
  });

  describe('WCAG 2.1 Compliance', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    /**
     * Test compliance with WCAG 2.1 guidelines
     * Ensures the settings panel meets accessibility standards
     */
    it('should meet WCAG 2.1 Level AA guidelines', () => {
      settingsPanel.open();
      
      // 1.3.1 Info and Relationships - Semantic markup
      const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
      expect(headings.length).toBeGreaterThan(0);
      
      const form = document.getElementById('settings-form');
      expect(form.getAttribute('role')).toBe('form');
      
      // 1.4.3 Contrast - Focus indicators
      const focusableElements = document.querySelectorAll('input, select, button');
      focusableElements.forEach(element => {
        element.focus();
        const style = window.getComputedStyle(element);
        expect(style.outline).not.toBe('none');
      });
      
      // 2.1.1 Keyboard - All functionality accessible via keyboard
      const interactiveElements = document.querySelectorAll('input, select, button, [tabindex]');
      interactiveElements.forEach(element => {
        expect(element.tabIndex).toBeGreaterThanOrEqual(0);
      });
      
      // 2.4.3 Focus Order - Logical tab sequence
      const tabbableElements = Array.from(interactiveElements).filter(el => el.tabIndex >= 0);
      expect(tabbableElements.length).toBeGreaterThan(0);
      
      // 3.2.2 On Input - No unexpected context changes
      // This is tested in other sections by verifying auto-save behavior
      
      // 4.1.2 Name, Role, Value - All controls have accessible names
      interactiveElements.forEach(element => {
        const hasLabel = element.getAttribute('aria-label') || 
                        element.getAttribute('aria-labelledby') ||
                        element.closest('label') ||
                        document.querySelector(`label[for="${element.id}"]`);
        expect(hasLabel).toBeTruthy();
      });
    });

    it('should have proper heading hierarchy', () => {
      const h2 = document.querySelector('h2');
      expect(h2).toBeTruthy();
      expect(h2.textContent).toBe('Settings');
      
      // Should not skip heading levels
      const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'));
      const levels = headings.map(h => parseInt(h.tagName.charAt(1)));
      
      for (let i = 1; i < levels.length; i++) {
        expect(levels[i] - levels[i-1]).toBeLessThanOrEqual(1);
      }
    });

    it('should have meaningful page title', () => {
      expect(document.title).toContain('Settings');
      expect(document.title).toContain('CalendarBot');
    });

    it('should have language specified', () => {
      expect(document.documentElement.getAttribute('lang')).toBe('en');
    });

    it('should provide skip links for keyboard users', () => {
      settingsPanel.open();
      
      // Should be able to skip to main content
      const skipLink = document.querySelector('a[href="#settings-content"], button[data-skip-to="content"]');
      if (skipLink) {
        expect(skipLink.textContent).toContain('Skip');
      }
    });

    it('should meet timing requirements', async () => {
      // Auto-save should not interfere with user input
      settingsPanel.open();
      
      const refreshInput = document.getElementById('refresh-interval');
      refreshInput.focus();
      
      // User should have sufficient time to complete input
      refreshInput.value = '3';
      await testUtils.waitForTimeout(500); // Partial input
      
      refreshInput.value = '30';
      await testUtils.waitForTimeout(1100); // Complete input + auto-save delay
      
      // Should not save partial input
      expect(mockSettingsAPI.updateSetting).toHaveBeenCalledWith('refreshInterval', 30);
    });
  });

  describe('Integration with Assistive Technologies', () => {
    beforeEach(async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
    });

    it('should work with virtual focus mode', () => {
      // Simulate screen reader virtual cursor
      settingsPanel.open();
      
      const form = document.getElementById('settings-form');
      const formDescription = form.getAttribute('aria-describedby');
      
      if (formDescription) {
        const descElement = document.getElementById(formDescription);
        expect(descElement).toBeTruthy();
      }
    });

    it('should support voice control navigation', () => {
      settingsPanel.open();
      
      // Elements should have unique, speakable names
      const buttons = document.querySelectorAll('button');
      const buttonLabels = Array.from(buttons).map(btn => 
        btn.getAttribute('aria-label') || btn.textContent.trim()
      );
      
      const uniqueLabels = new Set(buttonLabels);
      expect(uniqueLabels.size).toBe(buttonLabels.length);
    });

    it('should support switch navigation', () => {
      settingsPanel.open();
      
      // All interactive elements should be reachable via switch scanning
      const interactiveElements = document.querySelectorAll('input, select, button, [tabindex="0"]');
      
      interactiveElements.forEach(element => {
        expect(element.tabIndex).toBeGreaterThanOrEqual(0);
        expect(element.style.display).not.toBe('none');
        expect(element.style.visibility).not.toBe('hidden');
      });
    });

    it('should provide sufficient context for screen readers', () => {
      settingsPanel.open();
      
      const form = document.getElementById('settings-form');
      const inputs = form.querySelectorAll('input, select');
      
      inputs.forEach(input => {
        // Each input should have context through labels or descriptions
        const hasContext = input.getAttribute('aria-label') ||
                          input.getAttribute('aria-labelledby') ||
                          input.getAttribute('aria-describedby') ||
                          input.closest('label') ||
                          document.querySelector(`label[for="${input.id}"]`);
        
        expect(hasContext).toBeTruthy();
      });
    });
  });
});