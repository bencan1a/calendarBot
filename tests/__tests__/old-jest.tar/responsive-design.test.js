/**
 * @fileoverview Comprehensive test suite for responsive design behavior
 * Tests screen size behavior, touch interfaces, and e-ink display optimizations
 */

describe('Responsive Design - Screen Size Behavior', () => {
  let settingsPanel;
  let gestureHandler;
  let mockSettingsAPI;
  let consoleLogSpy;

  // Standard screen sizes for testing
  const SCREEN_SIZES = {
    KINDLE_SMALL: { width: 300, height: 400 },
    KINDLE_MEDIUM: { width: 480, height: 800 },
    TABLET: { width: 768, height: 1024 },
    DESKTOP: { width: 1200, height: 800 },
    MOBILE_PORTRAIT: { width: 375, height: 667 },
    MOBILE_LANDSCAPE: { width: 667, height: 375 }
  };

  beforeEach(() => {
    // Reset DOM
    testUtils.cleanupDOM();
    
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    // Mock dependencies
    mockSettingsAPI = {
      getSettings: jest.fn(),
      updateSettings: jest.fn(),
      updateSetting: jest.fn(),
      validateSettings: jest.fn(),
      validateSetting: jest.fn()
    };

    // Load modules
    require('../../calendarbot/web/static/shared/js/settings-api.js');
    require('../../calendarbot/web/static/shared/js/gesture-handler.js');
    require('../../calendarbot/web/static/shared/js/settings-panel.js');
  });

  afterEach(() => {
    if (settingsPanel) {
      settingsPanel.destroy();
    }
    if (gestureHandler) {
      gestureHandler.destroy();
    }
    jest.clearAllMocks();
    testUtils.cleanupDOM();
    
    // Reset viewport
    testUtils.setViewportSize(1200, 800);
  });

  describe('Kindle Small Display (300×400px)', () => {
    beforeEach(() => {
      testUtils.setViewportSize(SCREEN_SIZES.KINDLE_SMALL.width, SCREEN_SIZES.KINDLE_SMALL.height);
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              .settings-panel { position: fixed; top: 0; right: -100%; width: 280px; height: 100%; transition: right 0.3s ease; }
              .settings-panel.open { right: 0; }
              .settings-form { padding: 10px; }
              .form-group { margin-bottom: 15px; }
              .form-group label { display: block; font-size: 14px; margin-bottom: 5px; }
              .form-group input, .form-group select { width: 100%; font-size: 16px; padding: 8px; }
              @media (max-width: 320px) {
                .settings-panel { width: 100%; }
                .form-group input, .form-group select { font-size: 18px; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-header">
                <h2>Settings</h2>
                <button class="settings-close" id="settings-close">×</button>
              </div>
              <div class="settings-content">
                <form id="settings-form" class="settings-form">
                  <div class="form-group">
                    <label for="theme">Theme</label>
                    <select id="theme" name="theme">
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="auto-save">Auto-save</label>
                    <input type="checkbox" id="auto-save" name="autoSave">
                  </div>
                  <div class="form-group">
                    <label for="refresh-interval">Refresh Interval</label>
                    <input type="number" id="refresh-interval" name="refreshInterval" min="1" max="60">
                  </div>
                </form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should adjust panel width for small Kindle screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      gestureHandler = new window.GestureHandler();
      settingsPanel = new window.SettingsPanel(mockSettingsAPI, gestureHandler);
      
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      // On very small screens, panel should take full width
      expect(computedStyle.width).toBe('100%');
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Adjusted for small screen (300x400)');
    });

    it('should increase touch target sizes for small screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      gestureHandler = new window.GestureHandler();
      settingsPanel = new window.SettingsPanel(mockSettingsAPI, gestureHandler);
      
      await settingsPanel.initialize();
      
      const selectElement = document.getElementById('theme');
      const numberInput = document.getElementById('refresh-interval');
      
      const selectStyle = window.getComputedStyle(selectElement);
      const inputStyle = window.getComputedStyle(numberInput);
      
      // Font size should be larger for better touch interaction
      expect(parseInt(selectStyle.fontSize)).toBeGreaterThanOrEqual(18);
      expect(parseInt(inputStyle.fontSize)).toBeGreaterThanOrEqual(18);
    });

    it('should adjust gesture zone for small screen height', async () => {
      gestureHandler = new window.GestureHandler();
      gestureHandler.initialize();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      const zoneHeight = parseInt(gestureZone.style.height);
      
      // Gesture zone should be proportionally smaller for small screens
      expect(zoneHeight).toBeLessThanOrEqual(30); // Reduced from default 50px
    });

    it('should handle form overflow with scrolling on small screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const contentElement = document.querySelector('.settings-content');
      const computedStyle = window.getComputedStyle(contentElement);
      
      expect(computedStyle.overflowY).toBe('auto');
      expect(computedStyle.maxHeight).toBeTruthy();
    });

    it('should optimize for e-ink refresh on small Kindle', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      // Check for e-ink optimizations
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('eink-optimized')).toBe(true);
      
      // Animations should be disabled or reduced
      const computedStyle = window.getComputedStyle(panelElement);
      expect(computedStyle.transitionDuration).toBe('0.1s'); // Faster for e-ink
    });
  });

  describe('Kindle Medium Display (480×800px)', () => {
    beforeEach(() => {
      testUtils.setViewportSize(SCREEN_SIZES.KINDLE_MEDIUM.width, SCREEN_SIZES.KINDLE_MEDIUM.height);
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              .settings-panel { position: fixed; top: 0; right: -350px; width: 350px; height: 100%; transition: right 0.3s ease; }
              .settings-panel.open { right: 0; }
              .settings-form { padding: 15px; }
              .form-group { margin-bottom: 20px; }
              @media (min-width: 480px) and (max-width: 800px) {
                .settings-panel { width: 70%; max-width: 400px; }
                .form-group { display: flex; flex-direction: column; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-header">
                <h2>Settings</h2>
                <button class="settings-close" id="settings-close">×</button>
              </div>
              <div class="settings-content">
                <form id="settings-form" class="settings-form">
                  <div class="form-group">
                    <label for="theme">Theme</label>
                    <select id="theme" name="theme">
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="event-filters">Event Filters</label>
                    <div class="filter-list" id="filter-list"></div>
                    <input type="text" id="new-filter" placeholder="Add filter">
                    <button type="button" id="add-filter-btn">Add</button>
                  </div>
                </form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should use medium panel width for Kindle medium screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      gestureHandler = new window.GestureHandler();
      settingsPanel = new window.SettingsPanel(mockSettingsAPI, gestureHandler);
      
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      // Should use 70% width, capped at 400px
      expect(computedStyle.width).toBe('70%');
      expect(computedStyle.maxWidth).toBe('400px');
    });

    it('should arrange form elements vertically for medium screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        eventFilter: ['work', 'personal']
      });
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const formGroups = document.querySelectorAll('.form-group');
      formGroups.forEach(group => {
        const computedStyle = window.getComputedStyle(group);
        expect(computedStyle.flexDirection).toBe('column');
      });
    });

    it('should handle filter list layout on medium screens', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({
        eventFilter: ['work', 'personal', 'family', 'meetings']
      });
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const filterList = document.getElementById('filter-list');
      const filterItems = filterList.querySelectorAll('.filter-item');
      
      expect(filterItems.length).toBe(4);
      
      // Should stack vertically on medium screens
      filterItems.forEach(item => {
        const computedStyle = window.getComputedStyle(item);
        expect(computedStyle.display).toBe('block');
      });
    });

    it('should adjust gesture sensitivity for medium touch screens', async () => {
      gestureHandler = new window.GestureHandler();
      gestureHandler.initialize();
      
      // Medium screens should have slightly larger drag threshold
      expect(gestureHandler.dragThreshold).toBe(25); // Increased from default 20px
      expect(gestureHandler.gestureZoneHeight).toBe(45); // Medium zone height
    });
  });

  describe('Desktop/Web Display (1200×800px)', () => {
    beforeEach(() => {
      testUtils.setViewportSize(SCREEN_SIZES.DESKTOP.width, SCREEN_SIZES.DESKTOP.height);
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <style>
              .settings-panel { position: fixed; top: 0; right: -400px; width: 400px; height: 100%; transition: right 0.3s ease; }
              .settings-panel.open { right: 0; }
              .settings-form { padding: 20px; }
              .form-group { margin-bottom: 25px; display: flex; align-items: center; }
              .form-group label { min-width: 150px; margin-right: 15px; }
              @media (min-width: 1024px) {
                .settings-panel { width: 450px; }
                .form-group { flex-direction: row; }
                .form-actions { display: flex; justify-content: space-between; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-header">
                <h2>Settings</h2>
                <button class="settings-close" id="settings-close">×</button>
              </div>
              <div class="settings-content">
                <form id="settings-form" class="settings-form">
                  <div class="form-group">
                    <label for="theme">Theme</label>
                    <select id="theme" name="theme">
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="refresh-interval">Refresh Interval</label>
                    <input type="number" id="refresh-interval" name="refreshInterval">
                  </div>
                  <div class="form-actions">
                    <button type="submit" id="save-settings">Save</button>
                    <button type="button" id="reset-settings">Reset</button>
                  </div>
                </form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should use full desktop panel width', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      gestureHandler = new window.GestureHandler();
      settingsPanel = new window.SettingsPanel(mockSettingsAPI, gestureHandler);
      
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('450px');
    });

    it('should arrange form elements horizontally for desktop', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const formGroups = document.querySelectorAll('.form-group');
      formGroups.forEach(group => {
        const computedStyle = window.getComputedStyle(group);
        expect(computedStyle.flexDirection).toBe('row');
        expect(computedStyle.alignItems).toBe('center');
      });
    });

    it('should support mouse interactions for desktop', async () => {
      gestureHandler = new window.GestureHandler();
      gestureHandler.initialize();
      gestureHandler.enable();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      
      // Test mouse events
      const mouseDownEvent = new MouseEvent('mousedown', { clientY: 25 });
      gestureZone.dispatchEvent(mouseDownEvent);
      
      expect(gestureHandler.gestureActive).toBe(true);
      
      const mouseMoveEvent = new MouseEvent('mousemove', { clientY: 60 });
      document.dispatchEvent(mouseMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(true);
    });

    it('should disable e-ink optimizations for desktop', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('eink-optimized')).toBe(false);
      
      // Normal animations for desktop
      const computedStyle = window.getComputedStyle(panelElement);
      expect(computedStyle.transitionDuration).toBe('0.3s');
    });

    it('should arrange action buttons horizontally for desktop', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const formActions = document.querySelector('.form-actions');
      const computedStyle = window.getComputedStyle(formActions);
      
      expect(computedStyle.display).toBe('flex');
      expect(computedStyle.justifyContent).toBe('space-between');
    });
  });

  describe('Mobile Portrait (375×667px)', () => {
    beforeEach(() => {
      testUtils.setViewportSize(SCREEN_SIZES.MOBILE_PORTRAIT.width, SCREEN_SIZES.MOBILE_PORTRAIT.height);
      testUtils.setupMockTouchDevice();
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
            <style>
              .settings-panel { position: fixed; top: 0; right: -100%; width: 100%; height: 100%; }
              .settings-panel.open { right: 0; }
              @media (max-width: 480px) {
                .settings-header { padding: 15px; }
                .settings-close { font-size: 24px; min-width: 44px; min-height: 44px; }
                .form-group { margin-bottom: 20px; }
                .form-group input, .form-group select { min-height: 44px; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-header">
                <h2>Settings</h2>
                <button class="settings-close" id="settings-close">×</button>
              </div>
              <div class="settings-content">
                <form id="settings-form" class="settings-form">
                  <div class="form-group">
                    <label for="theme">Theme</label>
                    <select id="theme" name="theme">
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                </form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should take full screen width on mobile portrait', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('100%');
      expect(computedStyle.height).toBe('100%');
    });

    it('should ensure touch targets meet accessibility standards', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const closeButton = document.getElementById('settings-close');
      const themeSelect = document.getElementById('theme');
      
      const closeStyle = window.getComputedStyle(closeButton);
      const selectStyle = window.getComputedStyle(themeSelect);
      
      // Minimum 44px touch targets
      expect(parseInt(closeStyle.minWidth)).toBeGreaterThanOrEqual(44);
      expect(parseInt(closeStyle.minHeight)).toBeGreaterThanOrEqual(44);
      expect(parseInt(selectStyle.minHeight)).toBeGreaterThanOrEqual(44);
    });

    it('should handle touch events properly on mobile', async () => {
      gestureHandler = new window.GestureHandler();
      gestureHandler.initialize();
      gestureHandler.enable();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      
      // Test touch events
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      gestureZone.dispatchEvent(touchStartEvent);
      
      expect(gestureHandler.gestureActive).toBe(true);
    });

    it('should prevent zoom on double tap', () => {
      const viewportMeta = document.querySelector('meta[name="viewport"]');
      expect(viewportMeta.getAttribute('content')).toContain('user-scalable=no');
    });
  });

  describe('Mobile Landscape (667×375px)', () => {
    beforeEach(() => {
      testUtils.setViewportSize(SCREEN_SIZES.MOBILE_LANDSCAPE.width, SCREEN_SIZES.MOBILE_LANDSCAPE.height);
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              .settings-panel { position: fixed; top: 0; right: -60%; width: 60%; height: 100%; }
              .settings-panel.open { right: 0; }
              @media (orientation: landscape) and (max-height: 500px) {
                .settings-content { max-height: calc(100vh - 60px); overflow-y: auto; }
                .form-group { margin-bottom: 15px; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-header">
                <h2>Settings</h2>
                <button class="settings-close" id="settings-close">×</button>
              </div>
              <div class="settings-content">
                <form id="settings-form" class="settings-form">
                  <div class="form-group">
                    <label for="theme">Theme</label>
                    <select id="theme" name="theme">
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="refresh-interval">Refresh</label>
                    <input type="number" id="refresh-interval" name="refreshInterval">
                  </div>
                </form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should adjust panel width for landscape mobile', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('60%');
    });

    it('should handle vertical scrolling in landscape', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const contentElement = document.querySelector('.settings-content');
      const computedStyle = window.getComputedStyle(contentElement);
      
      expect(computedStyle.maxHeight).toBe('calc(100vh - 60px)');
      expect(computedStyle.overflowY).toBe('auto');
    });

    it('should compact form spacing for landscape', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const formGroups = document.querySelectorAll('.form-group');
      formGroups.forEach(group => {
        const computedStyle = window.getComputedStyle(group);
        expect(parseInt(computedStyle.marginBottom)).toBeLessThanOrEqual(15);
      });
    });
  });

  describe('Orientation Change Handling', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot</title></head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-content">
                <form id="settings-form"></form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    /**
     * Test orientation change behavior to ensure panel adapts properly
     * when device orientation changes during settings usage
     */
    it('should handle orientation change from portrait to landscape', async () => {
      // Start in portrait
      testUtils.setViewportSize(375, 667);
      
      mockSettingsAPI.getSettings.mockResolvedValue({});
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
      
      const panelElement = document.getElementById('settings-panel');
      let computedStyle = window.getComputedStyle(panelElement);
      const portraitWidth = computedStyle.width;
      
      // Change to landscape
      testUtils.setViewportSize(667, 375);
      
      // Trigger orientation change event
      const orientationEvent = new Event('orientationchange');
      window.dispatchEvent(orientationEvent);
      
      await testUtils.waitForUpdates();
      
      computedStyle = window.getComputedStyle(panelElement);
      const landscapeWidth = computedStyle.width;
      
      expect(portraitWidth).not.toBe(landscapeWidth);
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: Orientation changed, adjusting layout');
    });

    it('should reposition gesture zone after orientation change', async () => {
      gestureHandler = new window.GestureHandler();
      gestureHandler.initialize();
      
      // Change orientation
      testUtils.setViewportSize(667, 375);
      
      const orientationEvent = new Event('orientationchange');
      window.dispatchEvent(orientationEvent);
      
      await testUtils.waitForUpdates();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone.style.width).toBe('100%');
    });

    it('should maintain panel open state during orientation change', async () => {
      mockSettingsAPI.getSettings.mockResolvedValue({});
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      settingsPanel.open();
      
      expect(settingsPanel.isOpen).toBe(true);
      
      // Change orientation
      const orientationEvent = new Event('orientationchange');
      window.dispatchEvent(orientationEvent);
      
      await testUtils.waitForUpdates();
      
      expect(settingsPanel.isOpen).toBe(true);
    });
  });

  describe('Media Query Integration', () => {
    beforeEach(() => {
      testUtils.setupMockDOM(`
        <html>
          <head>
            <title>CalendarBot</title>
            <style>
              .settings-panel { position: fixed; top: 0; right: -400px; width: 400px; }
              @media (max-width: 480px) {
                .settings-panel { width: 100%; right: -100%; }
              }
              @media (min-width: 481px) and (max-width: 768px) {
                .settings-panel { width: 70%; right: -70%; }
              }
              @media (min-width: 769px) {
                .settings-panel { width: 450px; right: -450px; }
              }
            </style>
          </head>
          <body>
            <div class="settings-panel" id="settings-panel">
              <div class="settings-content">
                <form id="settings-form"></form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should apply correct styles for small screens', async () => {
      testUtils.setViewportSize(320, 480);
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('100%');
    });

    it('should apply correct styles for medium screens', async () => {
      testUtils.setViewportSize(600, 800);
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('70%');
    });

    it('should apply correct styles for large screens', async () => {
      testUtils.setViewportSize(1200, 800);
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.width).toBe('450px');
    });
  });

  describe('E-ink Display Optimizations', () => {
    beforeEach(() => {
      // Mock e-ink device detection
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 Kindle/4.0',
        configurable: true
      });
      
      testUtils.setupMockDOM(`
        <html>
          <head><title>CalendarBot</title></head>
          <body>
            <div class="settings-panel eink-device" id="settings-panel">
              <div class="settings-content">
                <form id="settings-form"></form>
              </div>
            </div>
          </body>
        </html>
      `);
    });

    it('should detect e-ink device and apply optimizations', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('eink-optimized')).toBe(true);
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsPanel: E-ink device detected, applying optimizations');
    });

    it('should reduce animation duration for e-ink displays', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      // Faster transitions for better e-ink performance
      expect(computedStyle.transitionDuration).toBe('0.1s');
    });

    it('should use high contrast styling for e-ink', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      expect(panelElement.classList.contains('high-contrast')).toBe(true);
    });

    it('should disable unnecessary visual effects for e-ink', async () => {
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      const panelElement = document.getElementById('settings-panel');
      const computedStyle = window.getComputedStyle(panelElement);
      
      expect(computedStyle.boxShadow).toBe('none');
      expect(computedStyle.borderRadius).toBe('0px');
    });
  });

  describe('Performance Optimization for Different Screen Sizes', () => {
    it('should throttle resize events to prevent excessive recalculation', async () => {
      let resizeCallCount = 0;
      const originalResize = window.addEventListener;
      
      window.addEventListener = jest.fn((event, handler) => {
        if (event === 'resize') {
          resizeCallCount++;
        }
        return originalResize.call(window, event, handler);
      });
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      // Rapid resize events
      for (let i = 0; i < 10; i++) {
        const resizeEvent = new Event('resize');
        window.dispatchEvent(resizeEvent);
      }
      
      await testUtils.waitForTimeout(300);
      
      // Should be throttled
      expect(resizeCallCount).toBeLessThanOrEqual(5);
      
      window.addEventListener = originalResize;
    });

    it('should cache computed styles to avoid repeated calculations', async () => {
      const getComputedStyleSpy = jest.spyOn(window, 'getComputedStyle');
      
      settingsPanel = new window.SettingsPanel(mockSettingsAPI);
      await settingsPanel.initialize();
      
      // Multiple layout calculations
      settingsPanel.calculateLayout();
      settingsPanel.calculateLayout();
      settingsPanel.calculateLayout();
      
      // Should use cached values for repeated calls
      const callCount = getComputedStyleSpy.mock.calls.length;
      expect(callCount).toBeLessThan(10); // Reasonable threshold
      
      getComputedStyleSpy.mockRestore();
    });
  });
});