/**
 * @fileoverview Comprehensive test suite for gesture-handler.js
 * Tests Kindle-style touch interface, top zone detection, and drag functionality
 */

describe('GestureHandler - Kindle-style Touch Interface', () => {
  let gestureHandler;
  let mockSettingsPanel;
  let consoleLogSpy;

  beforeEach(() => {
    // Reset DOM
    testUtils.cleanupDOM();
    testUtils.setupMockDOM(`
      <html>
        <head><title>CalendarBot</title></head>
        <body>
          <div class="settings-panel" id="settings-panel">
            <div class="settings-header">
              <h2>Settings</h2>
              <button class="settings-close">×</button>
            </div>
            <div class="settings-content">Test Content</div>
          </div>
        </body>
      </html>
    `);

    // Mock settings panel
    mockSettingsPanel = {
      isOpen: false,
      open: jest.fn(),
      close: jest.fn(),
      startReveal: jest.fn(),
      updateReveal: jest.fn(),
      cancelReveal: jest.fn()
    };

    // Setup console spy
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    // Load GestureHandler
    require('../../calendarbot/web/static/shared/js/gesture-handler.js');
    
    // Create instance
    gestureHandler = new window.GestureHandler(mockSettingsPanel);
  });

  afterEach(() => {
    if (gestureHandler) {
      gestureHandler.destroy();
    }
    jest.clearAllMocks();
    testUtils.cleanupDOM();
  });

  describe('Initialization', () => {
    it('should create GestureHandler with default configuration', () => {
      expect(gestureHandler).toBeDefined();
      expect(gestureHandler.gestureZoneHeight).toBe(50);
      expect(gestureHandler.dragThreshold).toBe(20);
      expect(gestureHandler.isListening).toBe(false);
      expect(gestureHandler.isDragging).toBe(false);
    });

    it('should initialize gesture recognition system', () => {
      gestureHandler.initialize();
      
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Initialized with gesture zone height:', 50);
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Gesture recognition system initialized');
      expect(gestureHandler.isListening).toBe(false); // Not listening until enabled
    });

    it('should create gesture zone element', () => {
      gestureHandler.initialize();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone).toBeTruthy();
      expect(gestureZone.style.height).toBe('50px');
      expect(gestureZone.style.position).toBe('fixed');
      expect(gestureZone.style.top).toBe('0px');
      expect(gestureZone.style.width).toBe('100%');
    });

    it('should create drag indicator element', () => {
      gestureHandler.initialize();
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator).toBeTruthy();
      expect(dragIndicator.style.opacity).toBe('0');
      expect(dragIndicator.style.position).toBe('fixed');
    });

    it('should remove existing gesture zone before creating new one', () => {
      // Create first instance
      gestureHandler.initialize();
      const firstZone = document.getElementById('settings-gesture-zone');
      expect(firstZone).toBeTruthy();
      
      // Create second instance
      gestureHandler.createGestureZone();
      const secondZone = document.getElementById('settings-gesture-zone');
      expect(secondZone).toBeTruthy();
      expect(secondZone).not.toBe(firstZone);
    });
  });

  describe('Top Zone Detection', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
    });

    it('should detect touch start in gesture zone (within 50px)', () => {
      const touchEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchEvent);
      
      expect(gestureHandler.gestureActive).toBe(true);
      expect(gestureHandler.startY).toBe(25);
    });

    it('should ignore touch start outside gesture zone (beyond 50px)', () => {
      const touchEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 75 }]
      });
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchEvent);
      
      expect(gestureHandler.gestureActive).toBe(false);
    });

    it('should show drag indicator on touch start in gesture zone', () => {
      const touchEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchEvent);
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator.style.opacity).toBe('0.6');
    });

    it('should not start gesture if panel is transitioning', () => {
      gestureHandler.panelTransitioning = true;
      
      const touchEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchEvent);
      
      expect(gestureHandler.gestureActive).toBe(false);
    });

    it('should not start gesture if panel is already open', () => {
      mockSettingsPanel.isOpen = true;
      
      const touchEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchEvent);
      
      expect(gestureHandler.gestureActive).toBe(false);
    });
  });

  describe('Drag Threshold Validation', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
      
      // Start gesture
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchStartEvent);
    });

    it('should not trigger drag until 20px threshold is reached', () => {
      // Move less than threshold
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 35 }] // 10px movement
      });
      document.dispatchEvent(touchMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(false);
      expect(mockSettingsPanel.startReveal).not.toHaveBeenCalled();
    });

    it('should trigger drag when 20px threshold is reached', () => {
      // Move past threshold
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 50 }] // 25px movement
      });
      document.dispatchEvent(touchMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(true);
      expect(mockSettingsPanel.startReveal).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Drag threshold reached, starting panel reveal');
    });

    it('should ignore upward movement during drag', () => {
      // Move upward
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 15 }] // Moving up
      });
      document.dispatchEvent(touchMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(false);
    });

    it('should update panel position during drag', () => {
      // Start dragging
      const touchMoveEvent1 = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 50 }] // 25px movement
      });
      document.dispatchEvent(touchMoveEvent1);
      
      // Continue dragging
      const touchMoveEvent2 = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 75 }] // 50px movement
      });
      document.dispatchEvent(touchMoveEvent2);
      
      expect(mockSettingsPanel.updateReveal).toHaveBeenCalled();
    });
  });

  describe('Panel Show/Hide Behavior', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
      
      // Start gesture and begin dragging
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchStartEvent);
      
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 50 }] // Start dragging
      });
      document.dispatchEvent(touchMoveEvent);
    });

    it('should complete panel reveal on sufficient drag distance', () => {
      // End with sufficient drag distance (2x threshold = 40px)
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 65 }] // 40px from start
      });
      document.dispatchEvent(touchEndEvent);
      
      expect(mockSettingsPanel.open).toHaveBeenCalled();
      expect(gestureHandler.panelTransitioning).toBe(false);
    });

    it('should cancel panel reveal on insufficient drag distance', () => {
      // End with insufficient drag distance
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 55 }] // 30px from start, less than 2x threshold
      });
      document.dispatchEvent(touchEndEvent);
      
      expect(mockSettingsPanel.cancelReveal).toHaveBeenCalled();
      expect(gestureHandler.panelTransitioning).toBe(false);
    });

    it('should hide drag indicator on touch end', () => {
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 65 }]
      });
      document.dispatchEvent(touchEndEvent);
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator.style.opacity).toBe('0');
    });

    it('should reset gesture state on touch end', () => {
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 65 }]
      });
      document.dispatchEvent(touchEndEvent);
      
      expect(gestureHandler.gestureActive).toBe(false);
      expect(gestureHandler.isDragging).toBe(false);
      expect(gestureHandler.startY).toBe(0);
      expect(gestureHandler.currentY).toBe(0);
    });
  });

  describe('Mouse Event Support', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
    });

    it('should handle mouse down in gesture zone', () => {
      const mouseEvent = new MouseEvent('mousedown', { clientY: 25 });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(mouseEvent);
      
      expect(gestureHandler.gestureActive).toBe(true);
      expect(gestureHandler.startY).toBe(25);
    });

    it('should handle mouse move for dragging', () => {
      // Start with mouse down
      const mouseDownEvent = new MouseEvent('mousedown', { clientY: 25 });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(mouseDownEvent);
      
      // Move mouse to trigger drag
      const mouseMoveEvent = new MouseEvent('mousemove', { clientY: 50 });
      document.dispatchEvent(mouseMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(true);
      expect(mockSettingsPanel.startReveal).toHaveBeenCalled();
    });

    it('should handle mouse up to complete gesture', () => {
      // Start and drag with mouse
      const mouseDownEvent = new MouseEvent('mousedown', { clientY: 25 });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(mouseDownEvent);
      
      const mouseMoveEvent = new MouseEvent('mousemove', { clientY: 50 });
      document.dispatchEvent(mouseMoveEvent);
      
      const mouseUpEvent = new MouseEvent('mouseup', { clientY: 70 });
      document.dispatchEvent(mouseUpEvent);
      
      expect(mockSettingsPanel.open).toHaveBeenCalled();
    });
  });

  describe('Gesture Hints and Feedback', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
    });

    it('should show gesture hint on short tap in gesture zone', async () => {
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchStartEvent);
      
      // Short tap - end quickly with minimal movement
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 27 }] // 2px movement
      });
      
      // Mock Date.now to control touch duration
      const mockNow = jest.spyOn(Date, 'now');
      mockNow.mockReturnValueOnce(0); // touchStartTime
      mockNow.mockReturnValueOnce(200); // touchEndTime (200ms duration)
      
      document.dispatchEvent(touchEndEvent);
      
      // Wait for hint to appear
      await testUtils.waitForUpdates();
      
      const hint = document.querySelector('.gesture-hint');
      expect(hint).toBeTruthy();
      expect(hint.textContent).toBe('Drag down to open settings');
      
      mockNow.mockRestore();
    });

    it('should not show hint for long touches', async () => {
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      const gestureZone = document.getElementById('settings-gesture-zone');
      gestureZone.dispatchEvent(touchStartEvent);
      
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 27 }]
      });
      
      // Mock for long touch duration
      const mockNow = jest.spyOn(Date, 'now');
      mockNow.mockReturnValueOnce(0); // touchStartTime
      mockNow.mockReturnValueOnce(500); // touchEndTime (500ms duration)
      
      document.dispatchEvent(touchEndEvent);
      
      await testUtils.waitForUpdates();
      
      const hint = document.querySelector('.gesture-hint');
      expect(hint).toBeFalsy();
      
      mockNow.mockRestore();
    });
  });

  describe('Panel Dismissal', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
      mockSettingsPanel.isOpen = true;
    });

    it('should dismiss panel on click outside', () => {
      const clickEvent = new MouseEvent('click', { 
        target: document.body,
        bubbles: true 
      });
      document.dispatchEvent(clickEvent);
      
      expect(mockSettingsPanel.close).toHaveBeenCalled();
    });

    it('should not dismiss panel on click inside settings panel', () => {
      const settingsPanel = document.querySelector('.settings-panel');
      const clickEvent = new MouseEvent('click', { 
        target: settingsPanel,
        bubbles: true 
      });
      document.dispatchEvent(clickEvent);
      
      expect(mockSettingsPanel.close).not.toHaveBeenCalled();
    });

    it('should not dismiss panel on click in gesture zone', () => {
      const gestureZone = document.getElementById('settings-gesture-zone');
      const clickEvent = new MouseEvent('click', { 
        target: gestureZone,
        bubbles: true 
      });
      document.dispatchEvent(clickEvent);
      
      expect(mockSettingsPanel.close).not.toHaveBeenCalled();
    });

    it('should dismiss panel on Escape key', () => {
      const keyEvent = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(keyEvent);
      
      expect(mockSettingsPanel.close).toHaveBeenCalled();
    });

    it('should not dismiss panel on Escape key when panel is closed', () => {
      mockSettingsPanel.isOpen = false;
      
      const keyEvent = new KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(keyEvent);
      
      expect(mockSettingsPanel.close).not.toHaveBeenCalled();
    });
  });

  describe('Enable/Disable Functionality', () => {
    beforeEach(() => {
      gestureHandler.initialize();
    });

    it('should enable gesture recognition', () => {
      gestureHandler.enable();
      
      expect(gestureHandler.isListening).toBe(true);
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Gesture recognition enabled');
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone.style.pointerEvents).toBe('auto');
    });

    it('should disable gesture recognition', () => {
      gestureHandler.enable();
      gestureHandler.disable();
      
      expect(gestureHandler.isListening).toBe(false);
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Gesture recognition disabled');
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone.style.pointerEvents).toBe('none');
    });

    it('should reset gesture state when disabled', () => {
      gestureHandler.enable();
      
      // Start gesture
      gestureHandler.gestureActive = true;
      gestureHandler.isDragging = true;
      
      gestureHandler.disable();
      
      expect(gestureHandler.gestureActive).toBe(false);
      expect(gestureHandler.isDragging).toBe(false);
    });

    it('should hide drag indicator when disabled', () => {
      gestureHandler.enable();
      gestureHandler.showDragIndicator();
      
      gestureHandler.disable();
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator.style.opacity).toBe('0');
    });
  });

  describe('Responsive Gesture Zone', () => {
    beforeEach(() => {
      gestureHandler.initialize();
    });

    it('should update gesture zone height', () => {
      gestureHandler.updateGestureZoneHeight(40);
      
      expect(gestureHandler.gestureZoneHeight).toBe(40);
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Gesture zone height updated to:', 40);
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone.style.height).toBe('40px');
    });

    it('should update drag indicator position when zone height changes', () => {
      gestureHandler.updateGestureZoneHeight(40);
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator.style.top).toBe('40px');
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle missing gesture zone during event setup', () => {
      // Remove gesture zone
      const existingZone = document.getElementById('settings-gesture-zone');
      if (existingZone) {
        existingZone.remove();
      }
      
      expect(() => gestureHandler.setupEventListeners()).not.toThrow();
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Gesture zone not found during event setup');
    });

    it('should handle touch events without changedTouches', () => {
      gestureHandler.initialize();
      gestureHandler.enable();
      
      // Create touch event without proper changedTouches
      const touchEvent = new Event('touchstart');
      const gestureZone = document.getElementById('settings-gesture-zone');
      
      expect(() => gestureZone.dispatchEvent(touchEvent)).not.toThrow();
    });

    it('should handle multiple rapid gesture attempts', () => {
      gestureHandler.initialize();
      gestureHandler.enable();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      
      // Rapid touch events
      for (let i = 0; i < 5; i++) {
        const touchStartEvent = new TouchEvent('touchstart', {
          changedTouches: [{ clientY: 25 }]
        });
        gestureZone.dispatchEvent(touchStartEvent);
        
        const touchEndEvent = new TouchEvent('touchend', {
          changedTouches: [{ clientY: 30 }]
        });
        document.dispatchEvent(touchEndEvent);
      }
      
      // Should handle gracefully without errors
      expect(gestureHandler).toBeDefined();
    });
  });

  describe('Cleanup and Destruction', () => {
    beforeEach(() => {
      gestureHandler.initialize();
    });

    it('should remove gesture zone on destroy', () => {
      gestureHandler.destroy();
      
      const gestureZone = document.getElementById('settings-gesture-zone');
      expect(gestureZone).toBeFalsy();
    });

    it('should remove drag indicator on destroy', () => {
      gestureHandler.destroy();
      
      const dragIndicator = document.getElementById('settings-drag-indicator');
      expect(dragIndicator).toBeFalsy();
    });

    it('should log cleanup completion', () => {
      gestureHandler.destroy();
      
      expect(consoleLogSpy).toHaveBeenCalledWith('GestureHandler: Cleaned up and destroyed');
    });
  });

  describe('Integration with Settings Panel', () => {
    beforeEach(() => {
      gestureHandler.initialize();
      gestureHandler.enable();
    });

    /**
     * Test complex gesture sequence that simulates real user interaction
     * with proper timing and multiple touch points
     */
    it('should handle complete gesture sequence for panel reveal', async () => {
      const gestureZone = document.getElementById('settings-gesture-zone');
      
      // 1. Touch start in gesture zone
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      gestureZone.dispatchEvent(touchStartEvent);
      
      expect(gestureHandler.gestureActive).toBe(true);
      expect(mockSettingsPanel.startReveal).not.toHaveBeenCalled();
      
      // 2. Drag past threshold
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 50 }]
      });
      document.dispatchEvent(touchMoveEvent);
      
      expect(gestureHandler.isDragging).toBe(true);
      expect(mockSettingsPanel.startReveal).toHaveBeenCalled();
      
      // 3. Continue dragging with position updates
      const touchMoveEvent2 = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 75 }]
      });
      document.dispatchEvent(touchMoveEvent2);
      
      expect(mockSettingsPanel.updateReveal).toHaveBeenCalled();
      
      // 4. End with sufficient distance to open
      const touchEndEvent = new TouchEvent('touchend', {
        changedTouches: [{ clientY: 85 }] // 60px total drag
      });
      document.dispatchEvent(touchEndEvent);
      
      expect(mockSettingsPanel.open).toHaveBeenCalled();
      expect(gestureHandler.gestureActive).toBe(false);
      expect(gestureHandler.isDragging).toBe(false);
    });

    it('should calculate reveal percentage correctly', () => {
      gestureHandler.initialize();
      gestureHandler.enable();
      
      // Start gesture
      const gestureZone = document.getElementById('settings-gesture-zone');
      const touchStartEvent = new TouchEvent('touchstart', {
        changedTouches: [{ clientY: 25 }]
      });
      gestureZone.dispatchEvent(touchStartEvent);
      
      // Drag to trigger threshold
      const touchMoveEvent = new TouchEvent('touchmove', {
        changedTouches: [{ clientY: 50 }]
      });
      document.dispatchEvent(touchMoveEvent);
      
      // Verify updateReveal is called with calculated percentage
      expect(mockSettingsPanel.updateReveal).toHaveBeenCalled();
      
      // The exact percentage calculation depends on the maxDrag value (200px in the code)
      // At 25px drag distance, percentage should be 25/200 = 0.125
      const callArgs = mockSettingsPanel.updateReveal.mock.calls[0];
      expect(callArgs[0]).toBeCloseTo(0.125, 3);
    });
  });
});