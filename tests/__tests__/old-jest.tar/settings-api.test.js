/**
 * @fileoverview Comprehensive test suite for settings-api.js
 * Tests HTTP communication, retry logic, validation, and error handling
 */

describe('SettingsAPI - HTTP Communication', () => {
  let settingsAPI;
  let fetchMock;
  let consoleErrorSpy;
  let consoleLogSpy;

  // Mock response helpers
  const createMockResponse = (data, status = 200, ok = true) => ({
    ok,
    status,
    statusText: status === 200 ? 'OK' : 'Error',
    json: jest.fn().mockResolvedValue(data),
    text: jest.fn().mockResolvedValue(JSON.stringify(data)),
    headers: new Headers({ 'Content-Type': 'application/json' })
  });

  const createNetworkError = () => new Error('Network request failed');

  beforeEach(() => {
    // Setup DOM
    testUtils.cleanupDOM();
    testUtils.setupMockDOM(`
      <html>
        <head><title>CalendarBot</title></head>
        <body>
          <div id="app">Test App</div>
        </body>
      </html>
    `);

    // Mock fetch
    fetchMock = jest.fn();
    global.fetch = fetchMock;

    // Setup console spies
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

    // Load SettingsAPI
    require('../../calendarbot/web/static/shared/js/settings-api.js');
    
    // Create instance
    settingsAPI = new window.SettingsAPI();
  });

  afterEach(() => {
    jest.clearAllMocks();
    testUtils.cleanupDOM();
    delete global.fetch;
  });

  describe('Initialization', () => {
    it('should create SettingsAPI with default configuration', () => {
      expect(settingsAPI).toBeDefined();
      expect(settingsAPI.baseURL).toBe('/api/settings');
      expect(settingsAPI.timeout).toBe(10000);
      expect(settingsAPI.maxRetries).toBe(3);
      expect(settingsAPI.retryDelay).toBe(1000);
    });

    it('should create SettingsAPI with custom configuration', () => {
      const customAPI = new window.SettingsAPI({
        baseURL: '/custom/api',
        timeout: 5000,
        maxRetries: 2,
        retryDelay: 500
      });

      expect(customAPI.baseURL).toBe('/custom/api');
      expect(customAPI.timeout).toBe(5000);
      expect(customAPI.maxRetries).toBe(2);
      expect(customAPI.retryDelay).toBe(500);
    });

    it('should log initialization', () => {
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsAPI: Initialized with base URL:', '/api/settings');
    });
  });

  describe('GET Operations', () => {
    it('should fetch settings successfully', async () => {
      const mockSettings = {
        theme: 'dark',
        eventFilter: ['work', 'personal'],
        autoSave: true
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(mockSettings));

      const result = await settingsAPI.getSettings();

      expect(fetchMock).toHaveBeenCalledWith('/api/settings', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        signal: expect.any(AbortSignal)
      });
      
      expect(result).toEqual(mockSettings);
    });

    it('should fetch specific setting by key', async () => {
      const mockValue = ['work', 'personal'];
      fetchMock.mockResolvedValueOnce(createMockResponse({ eventFilter: mockValue }));

      const result = await settingsAPI.getSetting('eventFilter');

      expect(fetchMock).toHaveBeenCalledWith('/api/settings/eventFilter', expect.any(Object));
      expect(result).toEqual(mockValue);
    });

    it('should handle empty settings response', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse({}));

      const result = await settingsAPI.getSettings();

      expect(result).toEqual({});
    });

    it('should handle 404 for non-existent setting', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse(
        { error: 'Setting not found' }, 
        404, 
        false
      ));

      await expect(settingsAPI.getSetting('nonexistent')).rejects.toThrow('HTTP 404: Setting not found');
    });
  });

  describe('POST Operations', () => {
    it('should create new settings successfully', async () => {
      const newSettings = {
        theme: 'light',
        eventFilter: ['work']
      };

      const responseData = { ...newSettings, id: '123' };
      fetchMock.mockResolvedValueOnce(createMockResponse(responseData, 201));

      const result = await settingsAPI.createSettings(newSettings);

      expect(fetchMock).toHaveBeenCalledWith('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(newSettings),
        signal: expect.any(AbortSignal)
      });

      expect(result).toEqual(responseData);
    });

    it('should validate settings data before POST', async () => {
      const invalidSettings = {
        theme: 'invalid-theme',
        eventFilter: 'not-an-array'
      };

      await expect(settingsAPI.createSettings(invalidSettings)).rejects.toThrow('Invalid settings data');
      expect(fetchMock).not.toHaveBeenCalled();
    });

    it('should handle validation errors from server', async () => {
      const settings = { theme: 'dark' };
      
      fetchMock.mockResolvedValueOnce(createMockResponse(
        { error: 'Validation failed', details: ['Invalid theme value'] },
        400,
        false
      ));

      await expect(settingsAPI.createSettings(settings)).rejects.toThrow('HTTP 400: Validation failed');
    });
  });

  describe('PUT Operations', () => {
    it('should update settings successfully', async () => {
      const updatedSettings = {
        theme: 'dark',
        autoSave: false
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(updatedSettings));

      const result = await settingsAPI.updateSettings(updatedSettings);

      expect(fetchMock).toHaveBeenCalledWith('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(updatedSettings),
        signal: expect.any(AbortSignal)
      });

      expect(result).toEqual(updatedSettings);
    });

    it('should update single setting by key', async () => {
      const key = 'theme';
      const value = 'light';
      const responseData = { [key]: value };

      fetchMock.mockResolvedValueOnce(createMockResponse(responseData));

      const result = await settingsAPI.updateSetting(key, value);

      expect(fetchMock).toHaveBeenCalledWith(`/api/settings/${key}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ [key]: value }),
        signal: expect.any(AbortSignal)
      });

      expect(result).toEqual(value);
    });

    it('should validate individual setting updates', async () => {
      await expect(settingsAPI.updateSetting('theme', 'invalid-theme')).rejects.toThrow('Invalid setting value');
      expect(fetchMock).not.toHaveBeenCalled();
    });
  });

  describe('DELETE Operations', () => {
    it('should delete all settings successfully', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse({ success: true }, 204));

      const result = await settingsAPI.deleteSettings();

      expect(fetchMock).toHaveBeenCalledWith('/api/settings', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        signal: expect.any(AbortSignal)
      });

      expect(result).toEqual({ success: true });
    });

    it('should delete single setting by key', async () => {
      const key = 'eventFilter';
      fetchMock.mockResolvedValueOnce(createMockResponse({ deleted: key }, 204));

      const result = await settingsAPI.deleteSetting(key);

      expect(fetchMock).toHaveBeenCalledWith(`/api/settings/${key}`, {
        method: 'DELETE',
        headers: expect.any(Object),
        signal: expect.any(AbortSignal)
      });

      expect(result).toEqual({ deleted: key });
    });

    it('should handle delete of non-existent setting', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse(
        { error: 'Setting not found' },
        404,
        false
      ));

      await expect(settingsAPI.deleteSetting('nonexistent')).rejects.toThrow('HTTP 404: Setting not found');
    });
  });

  describe('Retry Logic', () => {
    beforeEach(() => {
      // Speed up tests by reducing retry delay
      settingsAPI.retryDelay = 10;
    });

    /**
     * Test automatic retry mechanism for transient network failures
     */
    it('should retry on network failures and succeed on retry', async () => {
      const mockSettings = { theme: 'dark' };
      
      // First two calls fail, third succeeds
      fetchMock
        .mockRejectedValueOnce(createNetworkError())
        .mockRejectedValueOnce(createNetworkError())
        .mockResolvedValueOnce(createMockResponse(mockSettings));

      const result = await settingsAPI.getSettings();

      expect(fetchMock).toHaveBeenCalledTimes(3);
      expect(result).toEqual(mockSettings);
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsAPI: Retrying request, attempt 1 of 3');
      expect(consoleLogSpy).toHaveBeenCalledWith('SettingsAPI: Retrying request, attempt 2 of 3');
    });

    it('should retry on 500 server errors', async () => {
      const mockSettings = { theme: 'dark' };
      
      fetchMock
        .mockResolvedValueOnce(createMockResponse({ error: 'Internal Server Error' }, 500, false))
        .mockResolvedValueOnce(createMockResponse(mockSettings));

      const result = await settingsAPI.getSettings();

      expect(fetchMock).toHaveBeenCalledTimes(2);
      expect(result).toEqual(mockSettings);
    });

    it('should not retry on 400 client errors', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse(
        { error: 'Bad Request' },
        400,
        false
      ));

      await expect(settingsAPI.getSettings()).rejects.toThrow('HTTP 400: Bad Request');
      expect(fetchMock).toHaveBeenCalledTimes(1);
    });

    it('should fail after maximum retries exceeded', async () => {
      fetchMock.mockRejectedValue(createNetworkError());

      await expect(settingsAPI.getSettings()).rejects.toThrow('Network request failed');
      expect(fetchMock).toHaveBeenCalledTimes(4); // Initial + 3 retries
      expect(consoleErrorSpy).toHaveBeenCalledWith('SettingsAPI: Request failed after 3 retries:', expect.any(Error));
    });

    it('should apply exponential backoff for retries', async () => {
      settingsAPI.retryDelay = 100; // Use longer delay to test timing
      
      fetchMock.mockRejectedValue(createNetworkError());
      
      const startTime = Date.now();
      
      try {
        await settingsAPI.getSettings();
      } catch (error) {
        // Expected to fail
      }
      
      const endTime = Date.now();
      const elapsed = endTime - startTime;
      
      // Should take at least: 100ms + 200ms + 400ms = 700ms (exponential backoff)
      expect(elapsed).toBeGreaterThan(600);
    });
  });

  describe('Request Timeout Handling', () => {
    it('should timeout long-running requests', async () => {
      settingsAPI.timeout = 100; // 100ms timeout

      // Mock a fetch that never resolves
      fetchMock.mockImplementation(() => new Promise(() => {}));

      await expect(settingsAPI.getSettings()).rejects.toThrow('Request timeout');
      expect(consoleErrorSpy).toHaveBeenCalledWith('SettingsAPI: Request timeout after 100ms');
    });

    it('should abort requests on timeout', async () => {
      settingsAPI.timeout = 50;
      
      const abortSpy = jest.fn();
      const mockController = {
        signal: { aborted: false },
        abort: abortSpy
      };
      
      jest.spyOn(global, 'AbortController').mockImplementation(() => mockController);
      fetchMock.mockImplementation(() => new Promise(() => {}));

      try {
        await settingsAPI.getSettings();
      } catch (error) {
        // Expected timeout
      }

      // Wait for timeout to trigger
      await new Promise(resolve => setTimeout(resolve, 60));
      
      expect(abortSpy).toHaveBeenCalled();
    });
  });

  describe('Data Validation', () => {
    describe('Settings Structure Validation', () => {
      it('should validate theme values', () => {
        expect(() => settingsAPI.validateSetting('theme', 'dark')).not.toThrow();
        expect(() => settingsAPI.validateSetting('theme', 'light')).not.toThrow();
        expect(() => settingsAPI.validateSetting('theme', 'auto')).not.toThrow();
        expect(() => settingsAPI.validateSetting('theme', 'invalid')).toThrow('Invalid theme value');
      });

      it('should validate eventFilter array', () => {
        expect(() => settingsAPI.validateSetting('eventFilter', ['work', 'personal'])).not.toThrow();
        expect(() => settingsAPI.validateSetting('eventFilter', [])).not.toThrow();
        expect(() => settingsAPI.validateSetting('eventFilter', 'not-array')).toThrow('eventFilter must be an array');
        expect(() => settingsAPI.validateSetting('eventFilter', [123])).toThrow('eventFilter items must be strings');
      });

      it('should validate boolean settings', () => {
        expect(() => settingsAPI.validateSetting('autoSave', true)).not.toThrow();
        expect(() => settingsAPI.validateSetting('autoSave', false)).not.toThrow();
        expect(() => settingsAPI.validateSetting('autoSave', 'true')).toThrow('autoSave must be a boolean');
      });

      it('should validate numeric settings', () => {
        expect(() => settingsAPI.validateSetting('refreshInterval', 60)).not.toThrow();
        expect(() => settingsAPI.validateSetting('refreshInterval', 0)).not.toThrow();
        expect(() => settingsAPI.validateSetting('refreshInterval', -1)).toThrow('refreshInterval must be non-negative');
        expect(() => settingsAPI.validateSetting('refreshInterval', '60')).toThrow('refreshInterval must be a number');
      });

      it('should reject unknown setting keys', () => {
        expect(() => settingsAPI.validateSetting('unknownKey', 'value')).toThrow('Unknown setting key: unknownKey');
      });
    });

    describe('Complete Settings Object Validation', () => {
      it('should validate complete settings object', () => {
        const validSettings = {
          theme: 'dark',
          eventFilter: ['work'],
          autoSave: true,
          refreshInterval: 30
        };

        expect(() => settingsAPI.validateSettings(validSettings)).not.toThrow();
      });

      it('should reject settings with invalid values', () => {
        const invalidSettings = {
          theme: 'invalid-theme',
          eventFilter: ['work'],
          autoSave: true
        };

        expect(() => settingsAPI.validateSettings(invalidSettings)).toThrow('Invalid theme value');
      });

      it('should allow partial settings objects', () => {
        const partialSettings = {
          theme: 'light'
        };

        expect(() => settingsAPI.validateSettings(partialSettings)).not.toThrow();
      });
    });
  });

  describe('Error Response Handling', () => {
    it('should parse error messages from response body', async () => {
      const errorResponse = {
        error: 'Validation failed',
        details: ['Invalid theme', 'Missing required field']
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(errorResponse, 400, false));

      await expect(settingsAPI.getSettings()).rejects.toThrow('HTTP 400: Validation failed');
    });

    it('should handle responses without error messages', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse({}, 500, false));

      await expect(settingsAPI.getSettings()).rejects.toThrow('HTTP 500: Request failed');
    });

    it('should handle malformed JSON responses', async () => {
      const malformedResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: jest.fn().mockRejectedValue(new Error('Invalid JSON')),
        text: jest.fn().mockResolvedValue('Internal Server Error')
      };

      fetchMock.mockResolvedValueOnce(malformedResponse);

      await expect(settingsAPI.getSettings()).rejects.toThrow('HTTP 500: Internal Server Error');
    });

    it('should log detailed error information', async () => {
      const errorResponse = {
        error: 'Database connection failed',
        details: ['Connection timeout', 'Retry limit exceeded']
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(errorResponse, 500, false));

      try {
        await settingsAPI.getSettings();
      } catch (error) {
        // Expected to fail
      }

      expect(consoleErrorSpy).toHaveBeenCalledWith('SettingsAPI: Request failed:', expect.stringContaining('Database connection failed'));
    });
  });

  describe('Response Processing', () => {
    it('should parse JSON responses correctly', async () => {
      const responseData = {
        theme: 'dark',
        nested: {
          value: 'test',
          array: [1, 2, 3]
        }
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(responseData));

      const result = await settingsAPI.getSettings();

      expect(result).toEqual(responseData);
      expect(result.nested.value).toBe('test');
      expect(result.nested.array).toEqual([1, 2, 3]);
    });

    it('should handle empty response bodies', async () => {
      const emptyResponse = {
        ok: true,
        status: 204,
        statusText: 'No Content',
        json: jest.fn().mockRejectedValue(new Error('No content')),
        text: jest.fn().mockResolvedValue('')
      };

      fetchMock.mockResolvedValueOnce(emptyResponse);

      const result = await settingsAPI.deleteSettings();

      expect(result).toEqual({});
    });

    it('should preserve data types in responses', async () => {
      const responseData = {
        stringValue: 'test',
        numberValue: 42,
        booleanValue: true,
        arrayValue: ['a', 'b'],
        objectValue: { key: 'value' },
        nullValue: null
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(responseData));

      const result = await settingsAPI.getSettings();

      expect(typeof result.stringValue).toBe('string');
      expect(typeof result.numberValue).toBe('number');
      expect(typeof result.booleanValue).toBe('boolean');
      expect(Array.isArray(result.arrayValue)).toBe(true);
      expect(typeof result.objectValue).toBe('object');
      expect(result.nullValue).toBeNull();
    });
  });

  describe('Request Headers and Configuration', () => {
    it('should include correct content-type headers', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse({}));

      await settingsAPI.getSettings();

      expect(fetchMock).toHaveBeenCalledWith(expect.any(String), {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        signal: expect.any(AbortSignal)
      });
    });

    it('should construct URLs correctly for different endpoints', async () => {
      fetchMock.mockResolvedValue(createMockResponse({}));

      await settingsAPI.getSettings();
      expect(fetchMock).toHaveBeenCalledWith('/api/settings', expect.any(Object));

      await settingsAPI.getSetting('theme');
      expect(fetchMock).toHaveBeenCalledWith('/api/settings/theme', expect.any(Object));

      await settingsAPI.updateSetting('theme', 'dark');
      expect(fetchMock).toHaveBeenCalledWith('/api/settings/theme', expect.any(Object));
    });

    it('should handle custom base URLs', async () => {
      const customAPI = new window.SettingsAPI({ baseURL: '/custom/api/v2' });
      
      fetchMock.mockResolvedValueOnce(createMockResponse({}));

      await customAPI.getSettings();

      expect(fetchMock).toHaveBeenCalledWith('/custom/api/v2', expect.any(Object));
    });
  });

  describe('Edge Cases and Robustness', () => {
    it('should handle null and undefined responses gracefully', async () => {
      fetchMock.mockResolvedValueOnce(createMockResponse(null));

      const result = await settingsAPI.getSettings();

      expect(result).toBeNull();
    });

    it('should handle concurrent requests', async () => {
      const mockData1 = { setting1: 'value1' };
      const mockData2 = { setting2: 'value2' };

      fetchMock
        .mockResolvedValueOnce(createMockResponse(mockData1))
        .mockResolvedValueOnce(createMockResponse(mockData2));

      const [result1, result2] = await Promise.all([
        settingsAPI.getSetting('setting1'),
        settingsAPI.getSetting('setting2')
      ]);

      expect(result1).toBe('value1');
      expect(result2).toBe('value2');
      expect(fetchMock).toHaveBeenCalledTimes(2);
    });

    it('should handle very large response payloads', async () => {
      // Create large mock data
      const largeData = {
        eventFilter: new Array(1000).fill('test-event'),
        largeString: 'x'.repeat(10000),
        nestedData: {}
      };

      // Add nested structure
      for (let i = 0; i < 100; i++) {
        largeData.nestedData[`key${i}`] = `value${i}`;
      }

      fetchMock.mockResolvedValueOnce(createMockResponse(largeData));

      const result = await settingsAPI.getSettings();

      expect(result.eventFilter).toHaveLength(1000);
      expect(result.largeString).toHaveLength(10000);
      expect(Object.keys(result.nestedData)).toHaveLength(100);
    });

    it('should handle special characters in setting values', async () => {
      const specialCharsData = {
        theme: 'dark-mode_v2.1',
        eventFilter: ['work & personal', 'family/friends', '@special events'],
        customNote: 'Test with "quotes" and \'apostrophes\' and \n newlines'
      };

      fetchMock.mockResolvedValueOnce(createMockResponse(specialCharsData));

      const result = await settingsAPI.getSettings();

      expect(result).toEqual(specialCharsData);
    });
  });
});